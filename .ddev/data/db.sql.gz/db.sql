-- MariaDB dump 10.19  Distrib 10.11.8-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.11.8-MariaDB-ubu2204-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` text NOT NULL,
  `icon` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `identifier` varchar(120) NOT NULL DEFAULT '',
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(120) NOT NULL DEFAULT '',
  `widgets` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `identifier` (`identifier`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
INSERT INTO `be_dashboards` VALUES
(1,0,1731073796,1731073796,0,0,0,0,'69b08930d26ea2f48c11d1535748d9cded293b53',1,'My dashboard','{\"23eab24bfbc5ba085a8cd4439d74752d12e975b9\":{\"identifier\":\"t3information\"},\"944563c701b7ffef5004b9762b395a06a497ba5e\":{\"identifier\":\"docGettingStarted\"}}');
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `non_exclude_fields` text DEFAULT NULL,
  `explicit_allowdeny` text DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` text DEFAULT NULL,
  `db_mountpoints` text DEFAULT NULL,
  `pagetypes_select` text DEFAULT NULL,
  `tables_select` text DEFAULT NULL,
  `tables_modify` text DEFAULT NULL,
  `groupMods` text DEFAULT NULL,
  `availableWidgets` text DEFAULT NULL,
  `mfa_providers` text DEFAULT NULL,
  `file_mountpoints` text DEFAULT NULL,
  `file_permissions` text DEFAULT NULL,
  `TSconfig` text DEFAULT NULL,
  `subgroup` text DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `category_perms` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
INSERT INTO `be_sessions` VALUES
('b8f22eafa68606ab87083e3973d2b6f96c61b1e9eaa4e54f63c68f91ae86a411','[DISABLED]',1,1737018418,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"32a40f7bb30660f780d49099f7dca278103ebce1cca3c355c3195f373814f570\";}');
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `username` varchar(50) NOT NULL DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `password` varchar(255) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `usergroup` text DEFAULT NULL,
  `lang` varchar(10) NOT NULL DEFAULT 'default',
  `email` varchar(255) NOT NULL DEFAULT '',
  `db_mountpoints` text DEFAULT NULL,
  `options` smallint(5) unsigned NOT NULL DEFAULT 0,
  `realName` varchar(80) NOT NULL DEFAULT '',
  `userMods` text DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `uc` mediumblob DEFAULT NULL,
  `file_mountpoints` text DEFAULT NULL,
  `file_permissions` text DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `TSconfig` text DEFAULT NULL,
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `category_perms` longtext DEFAULT NULL,
  `lastlogin` int(11) NOT NULL DEFAULT 0,
  `password_reset_token` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES
(1,0,1731073356,1731073356,0,0,0,0,NULL,'admin',0,'$argon2i$v=19$m=65536,t=16,p=1$SWRVVGRtYzg3c1RzNHloZQ$dZW3HSj9M8S5W3uzv7078Gl1PVqbh6EUian5/sRDrnE',1,NULL,'default','',NULL,0,'',NULL,'','a:9:{s:10:\"moduleData\";a:14:{s:28:\"dashboard/current_dashboard/\";s:40:\"69b08930d26ea2f48c11d1535748d9cded293b53\";s:6:\"web_ts\";a:1:{s:6:\"action\";s:25:\"web_typoscript_infomodify\";}s:25:\"web_typoscript_infomodify\";a:1:{s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:1;}}s:10:\"FormEngine\";a:2:{i:0;a:2:{s:32:\"581106f297d9eed8dec1190ee4d6b04d\";a:5:{i:0;s:19:\"The fiith Continent\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:3;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B3%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:3;s:3:\"pid\";i:4;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:97:\"/typo3/module/web/layout?token=41f134f55744585070a75fc228d691f5d832e2b1&id=4#element-tt_content-3\";}s:32:\"deac478137dd48a97e299bd046412e21\";a:5:{i:0;s:8:\"Glossary\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:2;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:98:\"/typo3/module/web/layout?token=41f134f55744585070a75fc228d691f5d832e2b1&id=3&#element-tt_content-2\";}}i:1;s:32:\"781003bb54284ba8b56dd4bb0a4d5808\";}s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:16:\"opendocs::recent\";a:8:{s:32:\"781003bb54284ba8b56dd4bb0a4d5808\";a:5:{i:0;s:9:\"Australia\";i:1;a:5:{s:4:\"edit\";a:1:{s:37:\"tx_in2glossar_domain_model_definition\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:60:\"&edit%5Btx_in2glossar_domain_model_definition%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:37:\"tx_in2glossar_domain_model_definition\";s:3:\"uid\";i:1;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=56a63d9f756849d710e6bcfadb9879091b7a1a7d&id=2&table=&pointer=1\";}s:32:\"0650189cb5a009745b874ca6b3a2fdeb\";a:5:{i:0;s:6:\"Zambia\";i:1;a:5:{s:4:\"edit\";a:1:{s:37:\"tx_in2glossar_domain_model_definition\";a:1:{i:25;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:61:\"&edit%5Btx_in2glossar_domain_model_definition%5D%5B25%5D=edit\";i:3;a:5:{s:5:\"table\";s:37:\"tx_in2glossar_domain_model_definition\";s:3:\"uid\";i:25;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=56a63d9f756849d710e6bcfadb9879091b7a1a7d&id=2&table=&pointer=1\";}s:32:\"d8935b1949ed70ec5e14171249a2f5f1\";a:5:{i:0;s:5:\"Yemen\";i:1;a:5:{s:4:\"edit\";a:1:{s:37:\"tx_in2glossar_domain_model_definition\";a:1:{i:24;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:61:\"&edit%5Btx_in2glossar_domain_model_definition%5D%5B24%5D=edit\";i:3;a:5:{s:5:\"table\";s:37:\"tx_in2glossar_domain_model_definition\";s:3:\"uid\";i:24;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=56a63d9f756849d710e6bcfadb9879091b7a1a7d&id=2&table=&pointer=1\";}s:32:\"f1a868e682c4ccf37af23a7ae439bea9\";a:5:{i:0;s:7:\"Vietnam\";i:1;a:5:{s:4:\"edit\";a:1:{s:37:\"tx_in2glossar_domain_model_definition\";a:1:{i:23;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:61:\"&edit%5Btx_in2glossar_domain_model_definition%5D%5B23%5D=edit\";i:3;a:5:{s:5:\"table\";s:37:\"tx_in2glossar_domain_model_definition\";s:3:\"uid\";i:23;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=56a63d9f756849d710e6bcfadb9879091b7a1a7d&id=2&table=&pointer=1\";}s:32:\"291b8c79315cf57ebd82db51292e1c3e\";a:5:{i:0;s:5:\"Spain\";i:1;a:5:{s:4:\"edit\";a:1:{s:37:\"tx_in2glossar_domain_model_definition\";a:1:{i:22;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:61:\"&edit%5Btx_in2glossar_domain_model_definition%5D%5B22%5D=edit\";i:3;a:5:{s:5:\"table\";s:37:\"tx_in2glossar_domain_model_definition\";s:3:\"uid\";i:22;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=56a63d9f756849d710e6bcfadb9879091b7a1a7d&id=2&table=&pointer=1\";}s:32:\"ed1f42aba6818a9a5b7638d66a28dbdb\";a:5:{i:0;s:4:\"Oman\";i:1;a:5:{s:4:\"edit\";a:1:{s:37:\"tx_in2glossar_domain_model_definition\";a:1:{i:21;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:61:\"&edit%5Btx_in2glossar_domain_model_definition%5D%5B21%5D=edit\";i:3;a:5:{s:5:\"table\";s:37:\"tx_in2glossar_domain_model_definition\";s:3:\"uid\";i:21;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=56a63d9f756849d710e6bcfadb9879091b7a1a7d&id=2&table=&pointer=1\";}s:32:\"0f867acdf36780344d94106148fda72e\";a:5:{i:0;s:6:\"Norway\";i:1;a:5:{s:4:\"edit\";a:1:{s:37:\"tx_in2glossar_domain_model_definition\";a:1:{i:20;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:61:\"&edit%5Btx_in2glossar_domain_model_definition%5D%5B20%5D=edit\";i:3;a:5:{s:5:\"table\";s:37:\"tx_in2glossar_domain_model_definition\";s:3:\"uid\";i:20;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=56a63d9f756849d710e6bcfadb9879091b7a1a7d&id=2&table=&pointer=1\";}s:32:\"15453983ca884f778a27f03fc8ca4bbe\";a:5:{i:0;s:10:\"Luxembourg\";i:1;a:5:{s:4:\"edit\";a:1:{s:37:\"tx_in2glossar_domain_model_definition\";a:1:{i:19;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:61:\"&edit%5Btx_in2glossar_domain_model_definition%5D%5B19%5D=edit\";i:3;a:5:{s:5:\"table\";s:37:\"tx_in2glossar_domain_model_definition\";s:3:\"uid\";i:19;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=56a63d9f756849d710e6bcfadb9879091b7a1a7d&id=2&table=&pointer=1\";}}s:23:\"web_typoscript_analyzer\";a:3:{s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:1;}s:18:\"constantConditions\";a:0:{}s:15:\"setupConditions\";a:0:{}}s:16:\"browse_links.php\";N;s:8:\"web_list\";a:1:{s:15:\"collapsedTables\";a:1:{s:10:\"tt_content\";s:1:\"0\";}}s:9:\"clipboard\";a:5:{s:6:\"normal\";a:2:{s:2:\"el\";a:0:{}s:4:\"mode\";s:0:\"\";}s:5:\"tab_1\";a:0:{}s:5:\"tab_2\";a:0:{}s:5:\"tab_3\";a:0:{}s:7:\"current\";s:6:\"normal\";}s:8:\"web_info\";a:1:{s:6:\"action\";s:17:\"web_info_overview\";}s:15:\"system_BelogLog\";a:1:{s:10:\"constraint\";s:337:\"O:39:\"TYPO3\\CMS\\Belog\\Domain\\Model\\Constraint\":11:{s:14:\"\0*\0userOrGroup\";s:1:\"0\";s:9:\"\0*\0number\";i:20;s:15:\"\0*\0workspaceUid\";i:-99;s:10:\"\0*\0channel\";s:3:\"php\";s:8:\"\0*\0level\";s:5:\"debug\";s:17:\"\0*\0startTimestamp\";i:0;s:15:\"\0*\0endTimestamp\";i:0;s:18:\"\0*\0manualDateStart\";N;s:17:\"\0*\0manualDateStop\";N;s:9:\"\0*\0pageId\";i:0;s:8:\"\0*\0depth\";i:0;}\";}s:29:\"web_typoscript_constanteditor\";a:2:{s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:1;}s:16:\"selectedCategory\";s:20:\"plugin.tx_in2glossar\";}s:17:\"typoscript_active\";a:6:{s:18:\"sortAlphabetically\";b:1;s:28:\"displayConstantSubstitutions\";b:1;s:15:\"displayComments\";b:1;s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:1;}s:18:\"constantConditions\";a:0:{}s:15:\"setupConditions\";a:0:{}}}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"moduleSessionID\";a:13:{s:28:\"dashboard/current_dashboard/\";s:40:\"61f1746f153cade735946f89d3dffa6bb74b5a7b\";s:6:\"web_ts\";s:40:\"fda4289544c9423811da71e9ccf380d20a46f9c1\";s:25:\"web_typoscript_infomodify\";s:40:\"61f1746f153cade735946f89d3dffa6bb74b5a7b\";s:10:\"FormEngine\";s:40:\"93dee441ec16d376535d649db1c6b0aa7691667e\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"93dee441ec16d376535d649db1c6b0aa7691667e\";s:16:\"opendocs::recent\";s:40:\"93dee441ec16d376535d649db1c6b0aa7691667e\";s:23:\"web_typoscript_analyzer\";s:40:\"61f1746f153cade735946f89d3dffa6bb74b5a7b\";s:16:\"browse_links.php\";s:40:\"93dee441ec16d376535d649db1c6b0aa7691667e\";s:9:\"clipboard\";s:40:\"61f1746f153cade735946f89d3dffa6bb74b5a7b\";s:8:\"web_info\";s:40:\"417be151122b448bc4a2b6fd0849aed538f0d365\";s:15:\"system_BelogLog\";s:40:\"fda4289544c9423811da71e9ccf380d20a46f9c1\";s:29:\"web_typoscript_constanteditor\";s:40:\"fda4289544c9423811da71e9ccf380d20a46f9c1\";s:17:\"typoscript_active\";s:40:\"fda4289544c9423811da71e9ccf380d20a46f9c1\";}s:17:\"BackendComponents\";a:1:{s:6:\"States\";a:1:{s:8:\"Pagetree\";a:1:{s:9:\"stateHash\";a:1:{s:3:\"0_1\";s:1:\"1\";}}}}s:10:\"modulemenu\";s:2:\"{}\";s:17:\"systeminformation\";s:45:\"{\"system_BelogLog\":{\"lastAccess\":1731507258}}\";s:10:\"navigation\";a:1:{s:5:\"width\";s:3:\"300\";}}',NULL,NULL,1,NULL,0,NULL,NULL,1737016838,''),
(2,0,1731073578,1731073578,0,0,0,0,NULL,'_cli_',0,'$argon2i$v=19$m=65536,t=16,p=1$eHJ4RmpteG5FTi4uTFIxcw$i4ES61/csL/GY0Bdp/ecznc0DQBajNzDcc/k9mBbMpQ',1,NULL,'default','',NULL,0,'',NULL,'','a:4:{s:10:\"moduleData\";a:0:{}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";}',NULL,NULL,1,NULL,0,NULL,NULL,0,'');
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_adminpanel_requestcache`
--

DROP TABLE IF EXISTS `cache_adminpanel_requestcache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_adminpanel_requestcache` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_adminpanel_requestcache`
--

LOCK TABLES `cache_adminpanel_requestcache` WRITE;
/*!40000 ALTER TABLE `cache_adminpanel_requestcache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_adminpanel_requestcache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_adminpanel_requestcache_tags`
--

DROP TABLE IF EXISTS `cache_adminpanel_requestcache_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_adminpanel_requestcache_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_adminpanel_requestcache_tags`
--

LOCK TABLES `cache_adminpanel_requestcache_tags` WRITE;
/*!40000 ALTER TABLE `cache_adminpanel_requestcache_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_adminpanel_requestcache_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_imagesizes`
--

DROP TABLE IF EXISTS `cache_imagesizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_imagesizes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_imagesizes`
--

LOCK TABLES `cache_imagesizes` WRITE;
/*!40000 ALTER TABLE `cache_imagesizes` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_imagesizes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_imagesizes_tags`
--

DROP TABLE IF EXISTS `cache_imagesizes_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_imagesizes_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_imagesizes_tags`
--

LOCK TABLES `cache_imagesizes_tags` WRITE;
/*!40000 ALTER TABLE `cache_imagesizes_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_imagesizes_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
INSERT INTO `cache_pages` VALUES
(2,'3_ef0163d9ab6b7321598d2eb90fd1b8d7cf47a6b8',1737036982,'x�\�\\�o\�Ʋ�9�+X7M\�\�ö\�\�\�\�8�O^>�ӠEcE���H.\�%�\��\�\�7�\�C�\�\�AܠMDr�3�3\�<H\�d\�\�?\n�R6\�\"l\rœ�P\�	d�\�$o᪻\�\�u��\�z��\��\�\�co�\�\��\�}�ǋX2y\�\�I�np<|�\�y��e�\�O[E>n\�\�\�\�m\�\�\�Pޜ��ȹ����\�\�h\�a\�\�}�\�D�\"\�\�K�L#\�\�\�S���\�\r�1o�q\�ɔ\'��Ep\�Ȭ\�{\�\�\'��/2\�\�fT\�E\�\�2\�r3\�k�R�yg3Ʋ��\�$\�\"\�D\�y��x\�\�\�\�͗�o6jS2]db2ͽ\�\�\�n�\�\�m{r�<؆w�\�QB&Xm\�k\�\�8�r�yG� �\�\�<\�\�4\'\�Xf1\�\�O��8��Qan\�~��\'���\"��\r�M6�\� ;��<\�/#�\���\�\�2$%��&Ӱ\\f-ϲ�i\�l\�\�\�Y��ُD2\�ʢ�-�/\"���\�-o�\�\�Ӗ�5\�q�\�ث6�6�\�v�l�`{<\�\�n��\��Ψ\�\�v:\�\�`g���;\�w;�Ao�\�\�b\n\��v�`\�8ᅝg�p�3\�\�\�\�\�\�\�\�\�\�\�N½\�#,D$��\�}m\��`\�_�\��\�\�4\"�?�\��{P�\�=\�\�qr�F݃��<\��?���\�D��\�@\�\�|\�\Z��y�\�v\�Ǭ�r{�\�v$���\�By�\�:h���\�\r���w\�\�x��-Ϛ\�Xj�~\�\�6�Ӟ#Ś�9�lvٜ\���˻���\r׆�nK�#Ts/h\�ڭT2Ѧ3\���\�\���O�o�r�\�V\��]��,���Ьܥ\�\�\�uݴ\�Vv.;����}f\�\�\�U?(ظ\�f\��up\�~��\�\�7\�Ԭ��\�\�m�\��\�G\�m��\��\'n����\�\�\�KT�w��G\�)\�W���\�?�g��\�\��&d\�@?X\�\�͵%`\�Ֆ4\�0\�xn\�\�\�\�澖\r\�\�v�\�lĂY.\�\�꾝\�c�ԓ#�\�\�ݬ\��\�f\��-��1\�A\�Aoj[-�vמ\nh�\�B\��3��\�?��k!w\�O�\r���0�L&\��\�y,�`�=\�\�HƱL\�E���\���\Z������q�	EЅƉ�*\"�\�\�\�W�m|�G�\�\�O�r\�Ι�Y\"���I\�L\�ý(M;�Q\r\�M� �9�f0\Zd\�\�\�\���\���d�\�\�,\�WEz\�ò\�\��\�\�\�\��[;[\��b��ů>\�<�\�\\�K��9T\�&�\�mS$�!pU\�u\�\�r#�+�4~p\�҆w��ʾ�(OF!:�\�8by�\�xa&h(�L\�HV��k.�%ag-U#\�Ȭ\�,��J�H��\���AP\0��[��B䠪�\�\�O\�a\�{��\�\Z]\�:`)�k$	\�2j�����x̫EU&df��\�T\�J1\0�Î0N$�p\�\� \�4\��4�A\�;�\�iy��+\����\�+\�\�	;Z��\�b�LTr�-g\�\�H�eg�;S\�\r�h��X���Y�RF`9)y\�\�\�n�������g\"\�Ae�,�N�\�b�Fd�4:�\�,tn�>�9x�c?ZT\�ᠻZ�h�\��p��A�Z4w��Ӂ�<ͽ�)�$�p,�ن��!\�	��Ѓlhqtr\��\n�{�DM/3fW\�*�\�q�\n�_=\\ \'	$�\Zp$�S@�\�>Z�i�p��Da\�\"\'\�\�)��J\Z�\���wWܦ�/�m&\�\�*��Z\�C_KUB$\�\�\�v���AgU��`D2\�\�!\�{\'�%�]#8��\�r��\�(-N1f��d%4\��WmmF�P2\��\�>u1��\�O;� @\Z�	�\�\�+�\�\�	�V��8\�t��\�\�d�a��r	bJ\�쎼v\��\�\�>��_	\�s�\�,�\�Y*l�%\�\ZeLʣl�iv�`CM`4�y�x\�T5wd\�i)�h6\�I\�0\�\�\�\�x䆽��欴\'�zx\�\�\'��4l�Ր)SBiRcU)�d�\"���� %�\��\"\��Hj��\�\�>|X��\�)�\��,CS1��\�ђe\ZYD\�H\�@��L�zΣ1��tn\�p�h�\r��C\�	\\��q[\�\ng\�\n\\kʏ�\ZH�ð�\�^7�g>eZvS��\�SM\�@,+8�,ϗ�y�T\�X9\�BJ���\�F�do�\�?FDch\"�8\�N�PY��z+�\�F\�\�4,\�Y �\�7����*m:/a!�/\�\�\���*2@\�$�t�Q\�g�\�\���\�N\�a�	�\ZGӴ8\�i\�Zo��]\�N\�N2\Z�ֈo\�ȣ��8MF�\�-ك�Y\r�t�\���\��\�\�:��G\�B���2�z\�ѿ9ȸ�\�o\�u�\�\�\�\����Y\�\�\�˙|\r5Y\n�F\��ɷ*	������\�`Ә%4������\�VJ\�\Z8܁ Kr#��\"�\�h9\0�&&.K�ڮ��\�x4E\�{o��<\�\�&�S\�>̂ȯxf\�	�l\��Y�S�\�ͭE{A\�-\n\r\�Lx\�\�\�\�\'bj�U�hJ>%7#Oa<d�\�\�N\�4���5�dRzF��$\\\ne\\(p��P�O�خ\�\�\�Qw��5���mC<�\�#�Ƭ<�\�\�r]��ީ���5G\�\�פ��X�n=\��,)����\�E��+7\�;N�M+ͦfpxb\�\�g���<��@\�3h�16�\�d�k�W\������\�=\�\�N%��d�sw�\r\�߰�hM0\��k8\�7xnY�s\�K���\�qF\�\�}�:\��g<ѿG��\�e\�@��1��Xs�\r_@r�\�r��=\�\r�\�BQC�}\�\�\�FS��EH\�?_=\�cST\�\�Nr\�\�X>U�<=gI1��N\�߈\�t�\���\��柊\�j�\�I\�C Ҏ\� d]\�-wYVz6\Z���6�~ɷ\�x.\\\�G\��=H\�l\�dr\�\�\0���5Pu��=\'�T\�UϘ��=�b\"]kg\�,�\r��b\�Sbrr\�\ZsHq�\�\�O\��P�g\�\"_r��\�#`r\�\r�]0�\nuER&+�\�\��ؒ\�\�K�	�e\�{ÒYEη,�P�\Z\�{�,fƛ|\'9\'/��R\�\�=1��5\�=�2a��]���9�]�s�s?�{P	��Xʒ;�\�\�5q>GM�)\�Ab\�ב]\�)탟��BW��N�cp\�+R��fUGܝ\�\�(����c��ｒ��\��׋B\�\�j}*frVض&:�)}}\�\�J\���R�[�������\�\�RH0\�X�\�+-\�\�#lf\�%a���4���\�\��\�\�B\��\��9��%̉���\��\�n%#�y���bԽW\�`]�\�\�jψϸ#/�s�\\\��qB\�\�\�\�3\�W\�\�(;-\�<P@DZ\n�	\�G\0�\�}]l�E��\�s���\�	�r\0\�|�*\�g\\\�b�{����\�\�\�\�H,\�X\�:\�3-Fz�@Ɛ\�����T\�\'[\�*�V�\�μ�#\�%�\�hϋ`�ug��f�>�\�`��\�\�\�C����Y,��h�Ju�Mձ�M�\� �C\�.\0Q�5�q0	BQ�V\�I\���j~I\�.\"anL���RHN.ʿ�\�\��mQ\�\�\�\�?�\�\�o�W�\��mn�o\�6~\�\�	\��\rح=�\�f�\">&\�\\�!(\�8OV�\�\�\rz�\�vg}�w�\�\�w��\�\�t^W��^�}�{M�l\�\�_-�D\�\�H\�\�n��A�H\'���tY�M\�º��\�l(�\�T\�ٌ�k\�:�IG�D\�\"/�͜=�%\��]�t\�\�t\�\�G\0c\r=j3$U���=�\�\�ݑ���U{\�<\�\�\�k�D6ޠ���Ԝ��\�\\�����I�\�9t!S\�\�6Y\'5c�:������|y��m*�1�\����\�\�\�\�:\�\�4ɔ;O���>\�Z�\�-���lʺ��I���\ZC��\�\�\�놶Wya�\�\����S.`1�o\�T\�(\�\"�ÓK��$6�h\�@\�k�W+2x��?@�W�u\�\0���5-\Z�Xv\r5�&ڕ6\�\�<uY�\�\��\�DR{\�8L�B@n1���ʈoĂuw�\�\�6\�\�\�\�s\�\��sM%I#\�k�H*/\��A^-hk\�?l\�0\�\�X\�s�X.�\�jx\�\��\�\��M\�ut�X�;�\0�2\06�\�;�\r܌�\�$˜\��7�Z�e���\��\�br�Fl�6^J$�h0Y��Њ�*\�Y@�G\�,��\Z��&mm�I~\�)9IZ�JQ�!.��\�\�T\�\���q�x�R\\J���T9�L+\�58+4Dj;\�Ϋa(��\�\����\�\��\�\���f\�7*\�dfp\���c��\0�.�Z\"y�G�0���\�\��;{;\�\�S�\�\���J����\�\0\n\��\'�)6�L%\�\�g\�\�\\\�E�\�u\�f�$��\�\�)������ސ\�~u�\�q�\��\�\�W	�g[C+��T��\�O\�峷\��\�>���	��\���*,\�Y��w����o�a\�L�PׅX�\�\�\���MX��\�\�]R9U.\�(�7i\�A�\�h(\�\�Y�\�\�#\�2\n�Új��\�F`\�ZPY�\00S��\�9+US+{1ǳ\�\�\��{\�T�\�\��\�\�\�\�\�\\\�t\��Ԉ\��\�\�\�q�-��\�ʩf}�\�f\�\�fM]\�\�*�\r{\r\��\�Dϔ�z\�ki߃b�J\�\�\�\�s�s���\�XC@e��\�`�UC�%�\�yi?ֲ�|\�Jݪ-\�~\�\0�b3�d��w\�=\�!ݲUű\�tL\Z\���\�##N<+\r�!7\�k:�\�FT`ɩĶR�GQ\����8M�w.b\�\�\�\��`(a}+\�S�Ag�\�Z7+��\�\�}\"\�Z\�.��ѽorhl��I��j`l�s\n�\�4.Jv��2\�,�})FPC9�t\�\0\���jgˌ)��a���\��\�XG\�=�h��w\�;\����\�W\�|k��q�\nS\�8�@;|V\�Q4��\�@�{\�r-/r^d3~w�\�Y7\�\�\0\�\�GEG\�l&ܿ\�\�X�[sp\�aIzs�\�Om\�ŪN�\�Еd�M|�|\n�\�K�\��56\�\��\�lBsf1\��\�+� &>�\�UF5���t\�a�9�l�l5װ*�\�\���`;wa\�e�f��f�oJ�\��F��\�K\�ch�-�\�x>M�\�t4)*\�.\�\�\�F�:\�0 	\�T\\\�fFVv\�\�\�-Șη���lkeH���q`\�\n�Vn�,i\�\�i�\�bOH+\�\�Df�V\�\�\�ʑf�\�\�ᦆ^B�@���\��k\0ņ\��d\�\�oĬ�U�\�b֏\�?�����x�xvxg\rt�\Z���Jz\�\�ĝ+\�\�lJS\�߿�:%IӘ0��\��w\�`g\�h��|]kiK\�.\��B�\�^\�\�\�¸�+�;\��q\����PP�P\0�\�J\�IN\�\�G^m\�\Z ;)t�،d�\����7éW��[U\���5��x�\�T\�\�8��؜	\�0\�R��|%\0��)�VMo.)\�q\\L�\\ u7�\�{́���z1%]St�v:�/h��IwR\�*5Ts\�K\�H2�h�ڹ�I\�\�\�{W\�\�\�o\�p�J\�\����&�Ӕ\����⤠\�\�\���7\�H*Θ\�\�\�ߎ����\�36���� w$\0P�q;\�_�\�E\�Vz����z�\�\�\�Y\���\�X�~\0��^Ge\����R�u�W[�\�IG^�d��t�\�\�\�G\�\\T],U\�&\�`\�g�N	���\�POtR�-ftK�Y\�ɯZ&RG�\�\�-���L¶�>v\��U�\�6j^��kZ���\rl�@\Z��Eʗ]\�΀E���\�Р�@0\�f,���Eݫ�\�\��\�ɹZ��\�\���L\�y\�\�P\�z\�xx����,bsA��+\Z�K�C\�Gl4ǯg2Ws�k\�X,\�\�P2�a\�\�<��\�4\�	�z\"7\�rWO\�\�\�/�	*o@��\�Պ*ΨX�1\��$\�U؇���v\�&\�h�=|P�G�vȇ\�\�\��p\�\��0q��\�z\�\�J\�gJ6\�x\��y�\�z\�)�[��\'��\�u�a�\�\�\�A@R~����\�I�>����Lwv\�Nw\�|\�>\"s�\�KA�ؠ\�]�\� z\�4�[�\�a\�T[�\�ߖ�\�\�\�ٟG2\��������.O\�\Z�\��\�W�\�\�1\�\�}�\0{�/�jB�Y\�i�w2Aթ\��\�[\�\�\��0��\�\�g�W2�ġ$\"<iu0~\��dzAV����Iӣ��y\�F?,rI�\�	��jG`=L���I�)ȉ9Ɯ\�[\�\'ۯ��@\�1ׅݪ\�\�T3�>7ߊ9\�&\�nU\�m���\0\�@�\�(:\�Kz!x��\��7\�o�%\�,s�\�[\�_\�\�\\h�ڪ��\�^)A\�G�y��\�{E�\�0D\�\�)�\\l��\�S�;B\�<�Y�\�\�W��\�2ȭ<b�-\�I�p\�fw�&b��\r\�~�\�ht��qd/gX\�י���.\�{\�C?\�*�\�m>�\�\�\�\\u�z\�\�s!�t�\�͹�\����\Z(�\�`W\�B�����qvyQ>��Bk�	�\�-�Y\�!7\"nLE\�\�\��X�2˩R\�\����\�;�$��Li]��ΤY\�\�Y1\"2�\� ��v\Zr�Μ\nyG\�\�&W\�΅�	(�SuA\�%\�kՅ5��H�7/d\�\�ө��0D�H�؋\�#*i\�\r�\�\�n����ffC\���2�\�\�a(\�,\�\�\�Tdf\�\�A\�\�\�\�\�\��r(N퓝�\�ζ~�g\�\�9�(�eJb%N>���t'),
(3,'1_ecd4e5e961c55749d42b5c5f90a274e0bdfff12f',1737101911,'x��V_s\�8>>�\�wb\�p���ʹM3\r\�p3�\�i\rj�\�ds\�\�~+\��\�\�^\�\�`\���\�J�t��\��\�t	�\�޹�\�\�dn 7~��(\Zy\�7��g\�?\�\�ʬ�igl�HF\�\�ăܳ�|\�\�\�`(a+�4��W��;�\�7\�.\��6_	M�`�����|�,v�\�.�.��� ���D�9x�\�N\�(I\0�\�D\�R1 �*d\�\�\�ھ^+��\'�Ѩ0�fَ0\�T?P]�\"\������Jh\�I&\�\Z�eΑ\�\�\��\�\�Ǔ�k&��˕!\�p8\�\��^Ddzl\�\\m1-d�\�*h���Y�PD�0#6�\�SJ���<�jM\r\�xl!�X�� ��\�#\�7�B\�O�Z��naG\��0L\�\�5��\�.F�(L�%�j�\�H]݉W%5�t\�Y\�L\�U6\�\�e�W\0\�#+\�ī<\ZX>\�XZ\�3��8#6`��Ei:�EG�`\�\�A�\�\��~\�~\�q/\n=�.\�\�\�Rئ��ä\�s�\�\�Y:<Fg�gC�\�\�8\n��Пa \"\�-3�5U-��8\�����_�\�x!�\�6o8=X ��!W��\�i�\�\�q�\�3\�bC�xb�9\�R\�j\��v9��\�L���A۱Lt��\'M׌�\�di��7}f\���!���\�˚\�X\�\�zǑ\�\�\�_ʌW��W��6�Q\r����\���\��g\�w��\n7I�TG��\�\��\�c��L\�1h\�\�\�\�)��w����9\�\�kFso�\�ޚ.h>=V������d��\�p%���\�\���k?J��/�M�~���\��u\�\�>^\�悩o\�\�K7H\��\\�\�`I�ӑg`k�\��~jVCӪ�B\�\nN\r\�\�\�gG\��3����,%VS|nkr�\�Fp;O,?���&?��QZW��\�\������T\�p\�|�\�t\�x\�߾Uy�m�i,\�`;}\�\0s[o\���\�`VJ>Y;�\�\\K��W[�n7\���3���\��\�6�#/@O�\�Ð1-�CVyrx\�\�2\�t��Ei���lfQ�e@\�&Q[	\�iY �\�#\�\�\r\�\�\�>\�h��&�8��XM�(�\�\�z�P\�\�n���2�*�e�\�]dٕ\�Z@\�\�M�ڂ��	�g|o\�Z���=B\�\�\�\�\r\�\�y\�W�=z\�\�nȪB\"H�sa\��i\�\�\�.C�	E�\Z\�\�\�ݥd�\�G\�Ы@����Z\�������w\\4v]i \�[?\�y%��(\�Ƨ��\�{5�\�58w_\�a�E����ȃ�=T\�I��aC\�+\�@C\�2�!9�9\�${V�J�m�E³Z\r�\�\"V�s\\�k\�B�\��޻�mw\�6e`[2Y*Y\�>\n\�\�M�\�\�}�_��p�X���\�\�龹:n�:\�]Q���\�V��D\�\�n\���k<�&ian[iOLd\�\�\�iXT��T $9�d��l�\�7\�\�6\�-\��U\���\�að\� @\�\�\�\��u,\�v�ӥn5Fu�!7<	���CԑK');
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
INSERT INTO `cache_pages_tags` VALUES
(2,'3_ef0163d9ab6b7321598d2eb90fd1b8d7cf47a6b8','pageId_3'),
(3,'1_ecd4e5e961c55749d42b5c5f90a274e0bdfff12f','pageId_1');
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
INSERT INTO `cache_rootline` VALUES
(1,'1__0_0_0_0',1739541763,'x�M�Mr�0�\�\�\0鯸@W\�${��ꉱ,\�f:�{\�\�+K���4\�@\r?�\�@#U��\�Y\�.l\�\�\�\�ҽ�\�Ì��E]e�Zg\Z\�0f�,Ա�>\��\Z\�R|��\��%�jSh�)\�(o\�8;\n�t\�b\�@�d\�\�\�}\�+(�$o�����Ҹ\�ʵ\���~��\�tJ�\�\�K7���\��\�pu�j�˸h8nD�\��d��\�_ .\�\�\'\".(\�E\�uS@M>\�F\�\�&\�\�-\�X\�qF�g\�x����'),
(3,'1__0_0_1_1',1739541840,'x�M�Mr�0�\�\�\0鯸@W\�${��ꉱ,\�f:�{\�\�+K���4\�@\r?�\�@#U��\�Y\�.l\�\�\�\�ҽ�\�Ì��E]e�Zg\Z\�0f�,Ա�>\��\Z\�R|��\��%�jSh�)\�(o\�8;\n�t\�b\�@�d\�\�\�}\�+(�$o�����Ҹ\�ʵ\���~��\�tJ�\�\�K7���\��\�pu�j�˸h8nD�\��d��\�_ .\�\�\'\".(\�E\�uS@M>\�F\�\�&\�\�-\�X\�qF�g\�x����'),
(19,'2__0_0_1_1',1739542509,'x�Ց\�n\� E��/0\�\�v����l�=\"��(6XfpE�\��M�����\�ʚ\�\�at�7|�@p�X\�f��\�SL��\��F3H�XE�W~��\�L*4o�Zli�\��P�\�uj�\�/R��\�mU���Zu\�����\�ڸ\�EO��[�}f�.\�3���\�\�c?i\�\�j��\�|\"-�!�z՘PH��ൟ%b�N�\�\�\�l�\�O\����n���\�Hl����\�\�\�\�G��/\���\�\\P\"\'U_\�>�b��Ε�M��t��\�Y���?�\�7ߙZ\'�{��1e޿\01�$�'),
(21,'3__0_0_1_1',1739542581,'x�\�Kn\�0D\��\�/}�v�M��q�ȒaQn� w/W��n\�UW�\�\�`FAe��*\��1-��ݦ�N5O\� ��p�~e��H\�=d�L4�\"L���!\�s�\'/և�\�Y�\�NMr�Ͳb�\�Q��V\�>RRe\�f�F�\0k\�#�鷧A�\�9a\'�\�\�\�Ȳ\�\�\�e9� ^>�}<�Ð�h�y��\��w\'Ӊf��\���H\�Z\�r��\n\�\�\�=en{\�!˯ʠ\�6\�\�8�\�\�\�\�\Z�tlVZ�\�n]�埅\�\n-�\�;��\��[f�7e^?\�\�&'),
(22,'3__0_0_0_0',1739542582,'x�\�Kn\�0D\��\�/}�v�M��q�ȒaQn� w/W��n\�UW�\�\�`FAe��*\��1-��ݦ�N5O\� ��p�~e��H\�=d�L4�\"L���!\�s�\'/և�\�Y�\�NMr�Ͳb�\�Q��V\�>RRe\�f�F�\0k\�#�鷧A�\�9a\'�\�\�\�Ȳ\�\�\�e9� ^>�}<�Ð�h�y��\��w\'Ӊf��\���H\�Z\�r��\n\�\�\�=en{\�!˯ʠ\�6\�\�8�\�\�\�\�\Z�tlVZ�\�n]�埅\�\n-�\�;��\��[f�7e^?\�\�&'),
(23,'4__0_0_1_1',1739542600,'x�命n\�0�_�\�\�N�G�]:eqvA�W�,\�6\�\�Pѵ�:\�y<\�)�\�b��T%\\l@F�za�i�Ӗ�g��q�>��YY$�2Z&\ZH&|\�Ԑ\�W@4��V��{\�Б�O��\�\��\"�\���\�Xu\�%yoFkt	���L�zx�N\�\�	\�e7�i�Q$����\�\�7\�aP�LD��LI�Ⱦi�;�NԻ\�w(D\"�k����\�W:&\�`G\�)s\��ɑ� �Jo�8��jO\�N\��c�\�\�v\�\�,�l��\�l�\�\�nA���o�\�ߔy�\�s)	'),
(24,'4__0_0_0_0',1739607511,'x�命n\�0�_�\�\�N�G�]:eqvA�W�,\�6\�\�Pѵ�:\�y<\�)�\�b��T%\\l@F�za�i�Ӗ�g��q�>��YY$�2Z&\ZH&|\�Ԑ\�W@4��V��{\�Б�O��\�\��\"�\���\�Xu\�%yoFkt	���L�zx�N\�\�	\�e7�i�Q$����\�\�7\�aP�LD��LI�Ⱦi�;�NԻ\�w(D\"�k����\�W:&\�`G\�)s\��ɑ� �Jo�8��jO\�N\��c�\�\�v\�\�,�l��\�l�\�\�nA���o�\�ߔy�\�s)	');
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
INSERT INTO `cache_rootline_tags` VALUES
(1,'1__0_0_0_0','pageId_1'),
(4,'1__0_0_1_1','pageId_1'),
(35,'2__0_0_1_1','pageId_2'),
(36,'2__0_0_1_1','pageId_1'),
(39,'3__0_0_1_1','pageId_3'),
(40,'3__0_0_1_1','pageId_1'),
(41,'3__0_0_0_0','pageId_3'),
(42,'3__0_0_0_0','pageId_1'),
(43,'4__0_0_1_1','pageId_4'),
(44,'4__0_0_1_1','pageId_1'),
(45,'4__0_0_0_0','pageId_4'),
(46,'4__0_0_0_0','pageId_1');
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_treelist`
--

DROP TABLE IF EXISTS `cache_treelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_treelist` (
  `md5hash` varchar(32) NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT 0,
  `treelist` mediumtext DEFAULT NULL,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`md5hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_treelist`
--

LOCK TABLES `cache_treelist` WRITE;
/*!40000 ALTER TABLE `cache_treelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_treelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` tinytext DEFAULT NULL,
  `TSconfig` text DEFAULT NULL,
  `felogin_redirectPid` tinytext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `lastlogin` int(11) NOT NULL DEFAULT 0,
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` text DEFAULT NULL,
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `uc` blob DEFAULT NULL,
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` tinytext DEFAULT NULL,
  `TSconfig` text DEFAULT NULL,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `felogin_redirectPid` tinytext DEFAULT NULL,
  `felogin_forgotHash` varchar(80) DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `doktype` int(10) unsigned NOT NULL DEFAULT 0,
  `TSconfig` text DEFAULT NULL,
  `is_siteroot` smallint(6) NOT NULL DEFAULT 0,
  `php_tree_stop` smallint(6) NOT NULL DEFAULT 0,
  `url` varchar(255) NOT NULL DEFAULT '',
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `target` varchar(80) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` text DEFAULT NULL,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `description` text DEFAULT NULL,
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `abstract` text DEFAULT NULL,
  `module` varchar(255) NOT NULL DEFAULT '',
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(6) NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `l18n_cfg` smallint(6) NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `lastUpdated` int(11) NOT NULL DEFAULT 0,
  `newUntil` int(11) NOT NULL DEFAULT 0,
  `slug` varchar(2048) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES
(1,0,1731073553,1731073553,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,0,NULL,0,0,0,0,1,1,31,31,1,'Home',1,NULL,1,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,1731080457,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/'),
(2,1,1731077390,1731077386,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,'Data',254,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/data'),
(3,1,1731077441,1731077439,0,0,0,0,'0',128,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,'Glossary',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,1736950581,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/glossary'),
(4,1,1731080340,1731080337,0,0,0,0,'0',64,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,'Standard Content',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,1731505808,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/standard-content');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext NOT NULL,
  `items` int(11) NOT NULL DEFAULT 0,
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`,`tablenames`,`fieldname`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `scope` varchar(264) NOT NULL,
  `mutation_identifier` text DEFAULT NULL,
  `mutation_collection` mediumtext DEFAULT NULL,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `missing` smallint(6) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `type` varchar(10) NOT NULL DEFAULT '',
  `metadata` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `size` bigint(20) unsigned NOT NULL DEFAULT 0,
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(11) NOT NULL DEFAULT 0,
  `folder_identifier` varchar(255) NOT NULL DEFAULT '',
  `recursive` smallint(6) NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `file` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `processing_url` text DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `description` text DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `link` varchar(1024) NOT NULL DEFAULT '',
  `crop` varchar(4000) NOT NULL DEFAULT '',
  `autoplay` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `driver` tinytext DEFAULT NULL,
  `configuration` text DEFAULT NULL,
  `is_default` smallint(6) NOT NULL DEFAULT 0,
  `is_browsable` smallint(6) NOT NULL DEFAULT 0,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `is_writable` smallint(6) NOT NULL DEFAULT 0,
  `is_online` smallint(6) NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(6) NOT NULL DEFAULT 1,
  `processingfolder` tinytext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES
(1,0,1731073824,1731073824,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.','fileadmin','Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',1,1,1,1,1,1,NULL);
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES
(1,1731077314,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"config\":\"page = PAGE\\npage.10 = TEXT\\npage.10.value (\\n   <div style=\\\"width: 800px; margin: 15% auto;\\\">\\n      <div style=\\\"width: 300px;\\\">\\n        <svg xmlns=\\\"http:\\/\\/www.w3.org\\/2000\\/svg\\\" viewBox=\\\"0 0 150 42\\\"><path d=\\\"M60.2 14.4v27h-3.8v-27h-6.7v-3.3h17.1v3.3h-6.6zm20.2 12.9v14h-3.9v-14l-7.7-16.2h4.1l5.7 12.2 5.7-12.2h3.9l-7.8 16.2zm19.5 2.6h-3.6v11.4h-3.8V11.1s3.7-.3 7.3-.3c6.6 0 8.5 4.1 8.5 9.4 0 6.5-2.3 9.7-8.4 9.7m.4-16c-2.4 0-4.1.3-4.1.3v12.6h4.1c2.4 0 4.1-1.6 4.1-6.3 0-4.4-1-6.6-4.1-6.6m21.5 27.7c-7.1 0-9-5.2-9-15.8 0-10.2 1.9-15.1 9-15.1s9 4.9 9 15.1c.1 10.6-1.8 15.8-9 15.8m0-27.7c-3.9 0-5.2 2.6-5.2 12.1 0 9.3 1.3 12.4 5.2 12.4 3.9 0 5.2-3.1 5.2-12.4 0-9.4-1.3-12.1-5.2-12.1m19.9 27.7c-2.1 0-5.3-.6-5.7-.7v-3.1c1 .2 3.7.7 5.6.7 2.2 0 3.6-1.9 3.6-5.2 0-3.9-.6-6-3.7-6H138V24h3.1c3.5 0 3.7-3.6 3.7-5.3 0-3.4-1.1-4.8-3.2-4.8-1.9 0-4.1.5-5.3.7v-3.2c.5-.1 3-.7 5.2-.7 4.4 0 7 1.9 7 8.3 0 2.9-1 5.5-3.3 6.3 2.6.2 3.8 3.1 3.8 7.3 0 6.6-2.5 9-7.3 9\\\"\\/><path fill=\\\"#FF8700\\\" d=\\\"M31.7 28.8c-.6.2-1.1.2-1.7.2-5.2 0-12.9-18.2-12.9-24.3 0-2.2.5-3 1.3-3.6C12 1.9 4.3 4.2 1.9 7.2 1.3 8 1 9.1 1 10.6c0 9.5 10.1 31 17.3 31 3.3 0 8.8-5.4 13.4-12.8M28.4.5c6.6 0 13.2 1.1 13.2 4.8 0 7.6-4.8 16.7-7.2 16.7-4.4 0-9.9-12.1-9.9-18.2C24.5 1 25.6.5 28.4.5\\\"\\/><\\/svg>\\n      <\\/div>\\n      <h4 style=\\\"font-family: sans-serif;\\\">Welcome to a default website made with <a href=\\\"https:\\/\\/typo3.org\\\">TYPO3<\\/a><\\/h4>\\n   <\\/div>\\n)\\npage.100 = CONTENT\\npage.100 {\\n    table = tt_content\\n    select {\\n        orderBy = sorting\\n        where = {#colPos}=0\\n    }\\n}\\n\"},\"newRecord\":{\"config\":\"page = PAGE\\r\\npage.10 = TEXT\\r\\npage.10.value = <h1>in2glossar Dev Env<\\/h1>\\r\\npage.100 = CONTENT\\r\\npage.100 {\\r\\n    table = tt_content\\r\\n    select {\\r\\n        orderBy = sorting\\r\\n        where = {#colPos}=0\\r\\n    }\\r\\n}\\r\\n\"}}',0,'0400$4bf9cb68cb3cd4c0991a20b44c6f180c:35af6288617af54964e77af08c30949a'),
(2,1731077369,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"include_static_file\":\"EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/,EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/Styling\\/\",\"description\":\"This is an Empty Site Package TypoScript record.\\n\\nFor each website you need a TypoScript record on the main page of your website (on the top level). For better maintenance all TypoScript should be extracted into external files via @import \'EXT:site_myproject\\/Configuration\\/TypoScript\\/setup.typoscript\'\"},\"newRecord\":{\"include_static_file\":\"EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/,EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/Styling\\/,EXT:in2glossar\\/Configuration\\/TypoScript\",\"description\":\"This is an Empty Site Package TypoScript record.\\r\\n\\r\\nFor each website you need a TypoScript record on the main page of your website (on the top level). For better maintenance all TypoScript should be extracted into external files via @import \'EXT:site_myproject\\/Configuration\\/TypoScript\\/setup.typoscript\'\"}}',0,'0400$b1ead51841bf72c4eecef5bdd597c845:35af6288617af54964e77af08c30949a'),
(3,1731077386,1,'BE',1,0,2,'pages','{\"uid\":2,\"pid\":1,\"tstamp\":1731077386,\"crdate\":1731077386,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":256,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Data\",\"doktype\":254,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"lastUpdated\":0,\"newUntil\":0,\"slug\":\"\\/data\"}',0,'0400$792570410311e50c8c6388d9e6c31481:f11830df10b4b0bca2db34810c2241b3'),
(4,1731077390,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$f8e11a37ef02ee8c437dbec38c519ff1:f11830df10b4b0bca2db34810c2241b3'),
(5,1731077417,1,'BE',1,0,1,'tt_content','{\"uid\":1,\"rowDescription\":\"\",\"pid\":1,\"tstamp\":1731077417,\"crdate\":1731077417,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"menu_subpages\",\"header\":\"\",\"header_position\":\"\",\"bodytext\":null,\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":\"\",\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"date\":0,\"tx_in2glossar_exclude\":0}',0,'0400$56fb9736be6f373eb9447e508f05a58e:7fa2c035f26826fe83eeecaaeddc4d40'),
(6,1731077429,2,'BE',1,0,1,'tt_content','{\"oldRecord\":{\"header\":\"\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"header\":\"Test cases\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"pages\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"accessibility_title\\\":\\\"\\\",\\\"accessibility_bypass\\\":\\\"\\\",\\\"accessibility_bypass_text\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tx_in2glossar_exclude\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$4b3714a0c2d38c976ff190ea39208268:7fa2c035f26826fe83eeecaaeddc4d40'),
(7,1731077439,1,'BE',1,0,3,'pages','{\"uid\":3,\"pid\":1,\"tstamp\":1731077439,\"crdate\":1731077439,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":128,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Glossary\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"lastUpdated\":0,\"newUntil\":0,\"slug\":\"\\/glossary\"}',0,'0400$0eef42625a5ece7de3f6baa3bfd10fca:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(8,1731077441,2,'BE',1,0,3,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$80f7b33e138fd99ae297180e587f1083:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(9,1731077451,1,'BE',1,0,2,'tt_content','{\"uid\":2,\"rowDescription\":\"\",\"pid\":3,\"tstamp\":1731077451,\"crdate\":1731077451,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"list\",\"header\":\"\",\"header_position\":\"\",\"bodytext\":null,\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":\"\",\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"in2glossar_main\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"date\":0,\"tx_in2glossar_exclude\":0}',0,'0400$8293455bbb7738a5b61c5eec1ef082b5:01dbc21fdb1263685b9147b3b1596ea8'),
(10,1731077474,2,'BE',1,0,2,'tt_content','{\"oldRecord\":{\"header\":\"\",\"pages\":\"\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"header\":\"Glossary\",\"pages\":\"2\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"list_type\\\":\\\"\\\",\\\"pages\\\":\\\"\\\",\\\"recursive\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tx_in2glossar_exclude\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$1ab26b57540dabf30f0dc91012ca77d4:01dbc21fdb1263685b9147b3b1596ea8'),
(11,1731077732,1,'BE',1,0,1,'tx_in2glossar_domain_model_definition','{\"uid\":1,\"pid\":2,\"tstamp\":1731077732,\"crdate\":1731077732,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\",\"word\":\"Australien\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"<p><strong>Australia<\\/strong>, officially the <strong>Commonwealth of Australia<\\/strong>,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-21\\\"><sup>[<\\/sup><sup>17<\\/sup><sup>]<\\/sup><\\/a> is a country comprising <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Mainland_Australia\\\" title=\\\"Mainland Australia\\\">the mainland<\\/a> of the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia_(continent)\\\" title=\\\"Australia (continent)\\\">Australian continent<\\/a>, the island of <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Tasmania\\\" title=\\\"Tasmania\\\">Tasmania<\\/a> and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_islands_of_Australia\\\" title=\\\"List of islands of Australia\\\">numerous smaller islands<\\/a>.<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-22\\\"><sup>[<\\/sup><sup>18<\\/sup><sup>]<\\/sup><\\/a> Australia has a total area of 7,688,287&nbsp;km<sup>2<\\/sup> (2,968,464&nbsp;sq&nbsp;mi), making it the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_countries_and_dependencies_by_area\\\" title=\\\"List of countries and dependencies by area\\\">sixth-largest country in the world<\\/a> and the largest country by area in <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Oceania\\\" title=\\\"Oceania\\\">Oceania<\\/a>. It is the world\'s oldest,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-23\\\"><sup>[<\\/sup><sup>19<\\/sup><sup>]<\\/sup><\\/a> flattest,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-24\\\"><sup>[<\\/sup><sup>20<\\/sup><sup>]<\\/sup><\\/a> and driest inhabited continent,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-25\\\"><sup>[<\\/sup><sup>21<\\/sup><sup>]<\\/sup><\\/a><a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-26\\\"><sup>[<\\/sup><sup>22<\\/sup><sup>]<\\/sup><\\/a> with some of the least fertile soils.<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-27\\\"><sup>[<\\/sup><sup>23<\\/sup><sup>]<\\/sup><\\/a><a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-28\\\"><sup>[<\\/sup><sup>24<\\/sup><sup>]<\\/sup><\\/a> It is a <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Megadiverse_countries\\\" title=\\\"Megadiverse countries\\\">megadiverse country<\\/a>, and its size gives it a wide variety of landscapes and climates including <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Deserts_of_Australia\\\" title=\\\"Deserts of Australia\\\">deserts<\\/a> in the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Outback\\\" title=\\\"Outback\\\">interior<\\/a> and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Forests_of_Australia\\\" title=\\\"Forests of Australia\\\">tropical rainforests<\\/a> along the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Eastern_states_of_Australia\\\" title=\\\"Eastern states of Australia\\\">coast<\\/a>.<\\/p>\",\"tooltip\":0}',0,'0400$dc4e4a6d35ab635bb2be1966232c8b25:d2b7b2935ce6ff53dca8bf6e5561666f'),
(12,1731077778,1,'BE',1,0,2,'tx_in2glossar_domain_model_definition','{\"uid\":2,\"pid\":2,\"tstamp\":1731077778,\"crdate\":1731077778,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\",\"word\":\"England\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"<p><strong>England<\\/strong> is a <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Countries_of_the_United_Kingdom\\\" title=\\\"Countries of the United Kingdom\\\">country<\\/a> that is part of the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/United_Kingdom\\\" title=\\\"United Kingdom\\\">United Kingdom<\\/a>.<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/England#cite_note-ONS_Geography_Guide-9\\\"><sup>[<\\/sup><sup>6<\\/sup><sup>]<\\/sup><\\/a> It is located on the island of <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Great_Britain\\\" title=\\\"Great Britain\\\">Great Britain<\\/a>, of which it covers about 62%, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_islands_of_England\\\" title=\\\"List of islands of England\\\">more than 100 smaller adjacent islands<\\/a>. It has land borders with <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Scotland\\\" title=\\\"Scotland\\\">Scotland<\\/a> to the north and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Wales\\\" title=\\\"Wales\\\">Wales<\\/a> to the west, and is otherwise surrounded by the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/North_Sea\\\" title=\\\"North Sea\\\">North Sea<\\/a> to the east, the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/English_Channel\\\" title=\\\"English Channel\\\">English Channel<\\/a> to the south, the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Celtic_Sea\\\" title=\\\"Celtic Sea\\\">Celtic Sea<\\/a> to the south-west, and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Irish_Sea\\\" title=\\\"Irish Sea\\\">Irish Sea<\\/a> to the west. <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Continental_Europe\\\" title=\\\"Continental Europe\\\">Continental Europe<\\/a> lies to the south-east, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Ireland\\\" title=\\\"Ireland\\\">Ireland<\\/a> to the west. At the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/2021_United_Kingdom_census\\\" title=\\\"2021 United Kingdom census\\\">2021 census<\\/a>, the population was 56,490,048.<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/England#cite_note-2021_Nomis-1\\\"><sup>[<\\/sup><sup>1<\\/sup><sup>]<\\/sup><\\/a> <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/London\\\" title=\\\"London\\\">London<\\/a> is both <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_urban_areas_in_the_United_Kingdom\\\" title=\\\"List of urban areas in the United Kingdom\\\">the largest city<\\/a> and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Capital_city\\\" title=\\\"Capital city\\\">capital<\\/a>.<\\/p>\",\"tooltip\":0}',0,'0400$45c22e145451d0aba88ef12548fad766:deccc9582a961b981e5b191666ccddd2'),
(13,1731077791,2,'BE',1,0,1,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"word\":\"Australien\",\"description\":\"<p><strong>Australia<\\/strong>, officially the <strong>Commonwealth of Australia<\\/strong>,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-21\\\"><sup>[<\\/sup><sup>17<\\/sup><sup>]<\\/sup><\\/a> is a country comprising <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Mainland_Australia\\\" title=\\\"Mainland Australia\\\">the mainland<\\/a> of the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia_(continent)\\\" title=\\\"Australia (continent)\\\">Australian continent<\\/a>, the island of <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Tasmania\\\" title=\\\"Tasmania\\\">Tasmania<\\/a> and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_islands_of_Australia\\\" title=\\\"List of islands of Australia\\\">numerous smaller islands<\\/a>.<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-22\\\"><sup>[<\\/sup><sup>18<\\/sup><sup>]<\\/sup><\\/a> Australia has a total area of 7,688,287&nbsp;km<sup>2<\\/sup> (2,968,464&nbsp;sq&nbsp;mi), making it the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_countries_and_dependencies_by_area\\\" title=\\\"List of countries and dependencies by area\\\">sixth-largest country in the world<\\/a> and the largest country by area in <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Oceania\\\" title=\\\"Oceania\\\">Oceania<\\/a>. It is the world\'s oldest,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-23\\\"><sup>[<\\/sup><sup>19<\\/sup><sup>]<\\/sup><\\/a> flattest,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-24\\\"><sup>[<\\/sup><sup>20<\\/sup><sup>]<\\/sup><\\/a> and driest inhabited continent,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-25\\\"><sup>[<\\/sup><sup>21<\\/sup><sup>]<\\/sup><\\/a><a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-26\\\"><sup>[<\\/sup><sup>22<\\/sup><sup>]<\\/sup><\\/a> with some of the least fertile soils.<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-27\\\"><sup>[<\\/sup><sup>23<\\/sup><sup>]<\\/sup><\\/a><a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-28\\\"><sup>[<\\/sup><sup>24<\\/sup><sup>]<\\/sup><\\/a> It is a <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Megadiverse_countries\\\" title=\\\"Megadiverse countries\\\">megadiverse country<\\/a>, and its size gives it a wide variety of landscapes and climates including <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Deserts_of_Australia\\\" title=\\\"Deserts of Australia\\\">deserts<\\/a> in the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Outback\\\" title=\\\"Outback\\\">interior<\\/a> and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Forests_of_Australia\\\" title=\\\"Forests of Australia\\\">tropical rainforests<\\/a> along the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Eastern_states_of_Australia\\\" title=\\\"Eastern states of Australia\\\">coast<\\/a>.<\\/p>\",\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\"},\"newRecord\":{\"word\":\"Australia\",\"description\":\"<p><strong>Australia<\\/strong>, officially the <strong>Commonwealth of Australia<\\/strong>,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-21\\\"><sup>[17]<\\/sup><\\/a> is a country comprising <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Mainland_Australia\\\" title=\\\"Mainland Australia\\\">the mainland<\\/a> of the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia_(continent)\\\" title=\\\"Australia (continent)\\\">Australian continent<\\/a>, the island of <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Tasmania\\\" title=\\\"Tasmania\\\">Tasmania<\\/a> and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_islands_of_Australia\\\" title=\\\"List of islands of Australia\\\">numerous smaller islands<\\/a>.<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-22\\\"><sup>[18]<\\/sup><\\/a> Australia has a total area of 7,688,287&nbsp;km<sup>2<\\/sup> (2,968,464&nbsp;sq&nbsp;mi), making it the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_countries_and_dependencies_by_area\\\" title=\\\"List of countries and dependencies by area\\\">sixth-largest country in the world<\\/a> and the largest country by area in <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Oceania\\\" title=\\\"Oceania\\\">Oceania<\\/a>. It is the world\'s oldest,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-23\\\"><sup>[19]<\\/sup><\\/a> flattest,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-24\\\"><sup>[20]<\\/sup><\\/a> and driest inhabited continent,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-25\\\"><sup>[21]<\\/sup><\\/a><a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-26\\\"><sup>[22]<\\/sup><\\/a> with some of the least fertile soils.<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-27\\\"><sup>[23]<\\/sup><\\/a><a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-28\\\"><sup>[24]<\\/sup><\\/a> It is a <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Megadiverse_countries\\\" title=\\\"Megadiverse countries\\\">megadiverse country<\\/a>, and its size gives it a wide variety of landscapes and climates including <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Deserts_of_Australia\\\" title=\\\"Deserts of Australia\\\">deserts<\\/a> in the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Outback\\\" title=\\\"Outback\\\">interior<\\/a> and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Forests_of_Australia\\\" title=\\\"Forests of Australia\\\">tropical rainforests<\\/a> along the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Eastern_states_of_Australia\\\" title=\\\"Eastern states of Australia\\\">coast<\\/a>.<\\/p>\",\"l10n_diffsource\":\"{\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\"}\"}}',0,'0400$870819badcdbf4c16fc23f6a5faec899:d2b7b2935ce6ff53dca8bf6e5561666f'),
(14,1731077867,1,'BE',1,0,3,'tx_in2glossar_domain_model_definition','{\"uid\":3,\"pid\":2,\"tstamp\":1731077867,\"crdate\":1731077867,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\",\"word\":\"India\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"<p><strong>India<\\/strong>, officially the <strong>Republic of India<\\/strong>,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/India#cite_note-30\\\"><sup>[<\\/sup><sup>j<\\/sup><sup>]<\\/sup><\\/a><a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/India#cite_note-31\\\"><sup>[<\\/sup><sup>21<\\/sup><sup>]<\\/sup><\\/a> is a country in <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/South_Asia\\\" title=\\\"South Asia\\\">South Asia<\\/a>. It is the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_countries_and_dependencies_by_area\\\" title=\\\"\\\">seventh-largest country in the world by area<\\/a> and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_countries_by_population_(United_Nations)\\\" title=\\\"List of countries by population (United Nations)\\\">most populous country<\\/a>. Bounded by the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Indian_Ocean\\\" title=\\\"Indian Ocean\\\">Indian Ocean<\\/a> on the south, the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Arabian_Sea\\\" title=\\\"Arabian Sea\\\">Arabian Sea<\\/a> on the southwest, and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Bay_of_Bengal\\\" title=\\\"Bay of Bengal\\\">Bay of Bengal<\\/a> on the southeast, it shares land borders with <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Pakistan\\\" title=\\\"Pakistan\\\">Pakistan<\\/a> to the west;<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/India#cite_note-33\\\"><sup>[<\\/sup><sup>k<\\/sup><sup>]<\\/sup><\\/a> <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/China\\\" title=\\\"China\\\">China<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Nepal\\\" title=\\\"Nepal\\\">Nepal<\\/a>, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Bhutan\\\" title=\\\"Bhutan\\\">Bhutan<\\/a> to the north; and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Bangladesh\\\" title=\\\"Bangladesh\\\">Bangladesh<\\/a> and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Myanmar\\\" title=\\\"Myanmar\\\">Myanmar<\\/a> to the east. In the Indian Ocean, India is in the vicinity of <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Sri_Lanka\\\" title=\\\"Sri Lanka\\\">Sri Lanka<\\/a> and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Maldives\\\" title=\\\"Maldives\\\">Maldives<\\/a>; its <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Andaman_and_Nicobar_Islands\\\" title=\\\"Andaman and Nicobar Islands\\\">Andaman and Nicobar Islands<\\/a> share a maritime border with <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Thailand\\\" title=\\\"Thailand\\\">Thailand<\\/a>, Myanmar, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Indonesia\\\" title=\\\"Indonesia\\\">Indonesia<\\/a>.<\\/p>\\r\\n\\r\\n\\r\\n\\r\\n\",\"tooltip\":0}',0,'0400$4454fb7d442acfad7b3c57ebc7510a6f:46334a3d8ac0b8573c76c9dcd24e0ec5'),
(15,1731077917,1,'BE',1,0,4,'tx_in2glossar_domain_model_definition','{\"uid\":4,\"pid\":2,\"tstamp\":1731077917,\"crdate\":1731077917,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\",\"word\":\"Mexico\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"<p><strong>Mexico<\\/strong>,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Mexico#cite_note-10\\\"><sup>[<\\/sup><sup>a<\\/sup><sup>]<\\/sup><\\/a><a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Mexico#cite_note-12\\\"><sup>[<\\/sup><sup>b<\\/sup><sup>]<\\/sup><\\/a> officially the <strong>United Mexican States<\\/strong>,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Mexico#cite_note-13\\\"><sup>[<\\/sup><sup>c<\\/sup><sup>]<\\/sup><\\/a> is a country in the southern portion of <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/North_America\\\" title=\\\"North America\\\">North America<\\/a>. Covering 1,972,550&nbsp;km<sup>2<\\/sup> (761,610 sq mi),<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Mexico#cite_note-cia.gov-14\\\"><sup>[<\\/sup><sup>11<\\/sup><sup>]<\\/sup><\\/a> it is the world\'s <a class=\\\"mw-redirect\\\" href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_countries_by_area\\\" title=\\\"List of countries by area\\\">13th largest country<\\/a> by area; with a population of almost 130 million, it is the <a class=\\\"mw-redirect\\\" href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_countries_by_population\\\" title=\\\"List of countries by population\\\">10th most populous<\\/a> country and has the most <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Hispanophone#Countries\\\" title=\\\"Hispanophone\\\">Spanish speakers<\\/a> in the world.<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Mexico#cite_note-2020_Census-1\\\"><sup>[<\\/sup><sup>1<\\/sup><sup>]<\\/sup><\\/a> Mexico is a <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Constitution_of_Mexico\\\" title=\\\"Constitution of Mexico\\\">constitutional<\\/a> republic comprising <a class=\\\"mw-redirect\\\" href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Mexican_state\\\" title=\\\"Mexican state\\\">31 states<\\/a> and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Mexico_City\\\" title=\\\"Mexico City\\\">Mexico City<\\/a>, its capital and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_cities_in_Mexico\\\" title=\\\"List of cities in Mexico\\\">largest city<\\/a>, which is among the <a class=\\\"mw-redirect\\\" href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_cities_by_population\\\" title=\\\"List of cities by population\\\">world\'s most populous metropolitan areas<\\/a>. The country shares land <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Borders_of_Mexico\\\" title=\\\"Borders of Mexico\\\">borders<\\/a> <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Mexico%E2%80%93United_States_border\\\" title=\\\"Mexico\\u2013United States border\\\">with the United States<\\/a> to the north, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Guatemala%E2%80%93Mexico_border\\\" title=\\\"Guatemala\\u2013Mexico border\\\">with Guatemala<\\/a> <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Belize%E2%80%93Mexico_border\\\" title=\\\"Belize\\u2013Mexico border\\\">and Belize<\\/a> to the southeast; as well as maritime borders with the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Pacific_Ocean\\\" title=\\\"Pacific Ocean\\\">Pacific Ocean<\\/a> to the west, the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Caribbean_Sea\\\" title=\\\"Caribbean Sea\\\">Caribbean Sea<\\/a> to the southeast, and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Gulf_of_Mexico\\\" title=\\\"Gulf of Mexico\\\">Gulf of Mexico<\\/a> to the east.<\\/p>\",\"tooltip\":0}',0,'0400$ee38d3584a3130ecd8a38e78cb202f19:0114b4062417f901ad0d42ab5ad32ada'),
(16,1731077946,1,'BE',1,0,5,'tx_in2glossar_domain_model_definition','{\"uid\":5,\"pid\":2,\"tstamp\":1731077946,\"crdate\":1731077946,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\",\"word\":\"Poland\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"<p><strong>Poland<\\/strong>,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Poland#cite_note-23\\\"><sup>[<\\/sup><sup>e<\\/sup><sup>]<\\/sup><\\/a> officially the <strong>Republic of Poland<\\/strong>,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Poland#cite_note-24\\\"><sup>[<\\/sup><sup>f<\\/sup><sup>]<\\/sup><\\/a> is a country in <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Central_Europe\\\" title=\\\"Central Europe\\\">Central Europe<\\/a>. It extends from the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Baltic_Sea\\\" title=\\\"Baltic Sea\\\">Baltic Sea<\\/a> in the north to the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Sudetes\\\" title=\\\"Sudetes\\\">Sudetes<\\/a> and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Carpathian_Mountains\\\" title=\\\"Carpathian Mountains\\\">Carpathian Mountains<\\/a> in the south, bordered by <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Lithuania\\\" title=\\\"Lithuania\\\">Lithuania<\\/a> and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Russia\\\" title=\\\"Russia\\\">Russia<\\/a><a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Poland#cite_note-25\\\"><sup>[<\\/sup><sup>g<\\/sup><sup>]<\\/sup><\\/a> to the northeast, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Belarus\\\" title=\\\"Belarus\\\">Belarus<\\/a> and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Ukraine\\\" title=\\\"Ukraine\\\">Ukraine<\\/a> to the east, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Slovakia\\\" title=\\\"Slovakia\\\">Slovakia<\\/a> and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Czech_Republic\\\" title=\\\"Czech Republic\\\">Czech Republic<\\/a> to the south, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Germany\\\" title=\\\"Germany\\\">Germany<\\/a> to the west. The territory is characterised by a varied landscape, diverse ecosystems, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Temperate_climate\\\" title=\\\"Temperate climate\\\">temperate transitional<\\/a> climate. Poland is composed of <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Voivodeships_of_Poland\\\" title=\\\"Voivodeships of Poland\\\">sixteen voivodeships<\\/a> and is the fifth most populous <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Member_state_of_the_European_Union\\\" title=\\\"Member state of the European Union\\\">member state of the European Union<\\/a> (EU), with over 38 million people, and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_European_countries_by_area\\\" title=\\\"List of European countries by area\\\">fifth largest EU country<\\/a> by land area, covering a combined area of 312,696&nbsp;km<sup>2<\\/sup> (120,733&nbsp;sq&nbsp;mi). The capital and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_cities_and_towns_in_Poland\\\" title=\\\"List of cities and towns in Poland\\\">largest city<\\/a> is <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Warsaw\\\" title=\\\"Warsaw\\\">Warsaw<\\/a>; other major cities include <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Krak%C3%B3w\\\" title=\\\"Krak\\u00f3w\\\">Krak\\u00f3w<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Wroc%C5%82aw\\\" title=\\\"Wroc\\u0142aw\\\">Wroc\\u0142aw<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/%C5%81%C3%B3d%C5%BA\\\" title=\\\"\\u0141\\u00f3d\\u017a\\\">\\u0141\\u00f3d\\u017a<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Pozna%C5%84\\\" title=\\\"Pozna\\u0144\\\">Pozna\\u0144<\\/a>, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Gda%C5%84sk\\\" title=\\\"Gda\\u0144sk\\\">Gda\\u0144sk<\\/a>.<\\/p>\",\"tooltip\":0}',0,'0400$504242063d7015641c2928e034a6a7b8:43e143529e3c218c02c465eadd1081ac'),
(17,1731077999,1,'BE',1,0,6,'tx_in2glossar_domain_model_definition','{\"uid\":6,\"pid\":2,\"tstamp\":1731077999,\"crdate\":1731077999,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\",\"word\":\"Romania\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"<p><strong>Romania<\\/strong><a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Romania#cite_note-12\\\"><sup>[<\\/sup><sup>a<\\/sup><sup>]<\\/sup><\\/a> is a country located at the crossroads of <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Central_Europe\\\" title=\\\"Central Europe\\\">Central<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Eastern_Europe\\\" title=\\\"Eastern Europe\\\">Eastern<\\/a>, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Southeast_Europe\\\" title=\\\"Southeast Europe\\\">Southeast Europe<\\/a>.<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Romania#cite_note-13\\\"><sup>[<\\/sup><sup>12<\\/sup><sup>]<\\/sup><\\/a><a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Romania#cite_note-14\\\"><sup>[<\\/sup><sup>13<\\/sup><sup>]<\\/sup><\\/a><a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Romania#cite_note-15\\\"><sup>[<\\/sup><sup>14<\\/sup><sup>]<\\/sup><\\/a> It borders <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Ukraine\\\" title=\\\"Ukraine\\\">Ukraine<\\/a> to the north and east, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Hungary\\\" title=\\\"Hungary\\\">Hungary<\\/a> to the west, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Serbia\\\" title=\\\"Serbia\\\">Serbia<\\/a> to the southwest, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Bulgaria\\\" title=\\\"Bulgaria\\\">Bulgaria<\\/a> to the south, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Moldova\\\" title=\\\"Moldova\\\">Moldova<\\/a> to the east, and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Black_Sea\\\" title=\\\"Black Sea\\\">Black Sea<\\/a> to the southeast. It has a mainly <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Continental_climate\\\" title=\\\"Continental climate\\\">continental climate<\\/a>, and an area of 238,397&nbsp;km<sup>2<\\/sup> (92,046&nbsp;sq&nbsp;mi) with a population of 19 million people (2023). Romania is the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_European_countries_by_area\\\" title=\\\"List of European countries by area\\\">twelfth-largest country<\\/a> in Europe and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_European_Union_member_states_by_population\\\" title=\\\"List of European Union member states by population\\\">sixth-most populous<\\/a> member state of the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/European_Union\\\" title=\\\"European Union\\\">European Union<\\/a>. Europe\'s second-longest river, the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Danube\\\" title=\\\"Danube\\\">Danube<\\/a>, empties into the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Danube_Delta\\\" title=\\\"Danube Delta\\\">Danube Delta<\\/a> in the southeast of the country. The <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Carpathian_Mountains\\\" title=\\\"\\\">Carpathian Mountains<\\/a> cross Romania from the north to the southwest and include <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Moldoveanu_Peak\\\" title=\\\"Moldoveanu Peak\\\">Moldoveanu Peak<\\/a>, at an altitude of 2,544&nbsp;m (8,346&nbsp;ft).<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Romania#cite_note-16\\\"><sup>[<\\/sup><sup>15<\\/sup><sup>]<\\/sup><\\/a> Romania\'s capital and largest city is <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Bucharest\\\" title=\\\"Bucharest\\\">Bucharest<\\/a>. Other major <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Urban_area\\\" title=\\\"Urban area\\\">urban centers<\\/a> include <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Cluj-Napoca\\\" title=\\\"Cluj-Napoca\\\">Cluj-Napoca<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Timi%C8%99oara\\\" title=\\\"Timi\\u0219oara\\\">Timi\\u0219oara<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Ia%C8%99i\\\" title=\\\"Ia\\u0219i\\\">Ia\\u0219i<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Constan%C8%9Ba\\\" title=\\\"Constan\\u021ba\\\">Constan\\u021ba<\\/a> and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Bra%C8%99ov\\\" title=\\\"Bra\\u0219ov\\\">Bra\\u0219ov<\\/a>.<\\/p>\",\"tooltip\":0}',0,'0400$df928e22a76f7d0357ac07d075a88e2b:25ba7be3f8552fa129791269cd55d6e5'),
(18,1731078045,1,'BE',1,0,7,'tx_in2glossar_domain_model_definition','{\"uid\":7,\"pid\":2,\"tstamp\":1731078045,\"crdate\":1731078045,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\",\"word\":\"Turkey\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"<p><strong>Turkey<\\/strong>,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Turkey#cite_note-12\\\"><sup>[<\\/sup><sup>a<\\/sup><sup>]<\\/sup><\\/a> officially the <strong>Republic of T\\u00fcrkiye<\\/strong>,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Turkey#cite_note-13\\\"><sup>[<\\/sup><sup>b<\\/sup><sup>]<\\/sup><\\/a> is a country mainly located in <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Anatolia\\\" title=\\\"Anatolia\\\">Anatolia<\\/a> in <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/West_Asia\\\" title=\\\"West Asia\\\">West Asia<\\/a>, with a smaller part called <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/East_Thrace\\\" title=\\\"East Thrace\\\">East Thrace<\\/a> in <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Southeast_Europe\\\" title=\\\"Southeast Europe\\\">Southeast Europe<\\/a>. It borders the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Black_Sea\\\" title=\\\"Black Sea\\\">Black Sea<\\/a> to the north; <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Georgia_(country)\\\" title=\\\"Georgia (country)\\\">Georgia<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Armenia\\\" title=\\\"Armenia\\\">Armenia<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Azerbaijan\\\" title=\\\"Azerbaijan\\\">Azerbaijan<\\/a>, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Iran\\\" title=\\\"Iran\\\">Iran<\\/a> to the east; <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Iraq\\\" title=\\\"Iraq\\\">Iraq<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Syria\\\" title=\\\"Syria\\\">Syria<\\/a>, and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Mediterranean_Sea\\\" title=\\\"Mediterranean Sea\\\">Mediterranean Sea<\\/a> to the south; and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Aegean_Sea\\\" title=\\\"Aegean Sea\\\">Aegean Sea<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Greece\\\" title=\\\"Greece\\\">Greece<\\/a>, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Bulgaria\\\" title=\\\"Bulgaria\\\">Bulgaria<\\/a> to the west. Turkey is home to over 85 million people; most are ethnic <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Turkish_people\\\" title=\\\"Turkish people\\\">Turks<\\/a>, while ethnic <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Kurds\\\" title=\\\"Kurds\\\">Kurds<\\/a> are the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Minorities_in_Turkey\\\" title=\\\"Minorities in Turkey\\\">largest ethnic minority<\\/a>.<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Turkey#cite_note-cia-5\\\"><sup>[<\\/sup><sup>5<\\/sup><sup>]<\\/sup><\\/a> Officially <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Secularism_in_Turkey\\\" title=\\\"Secularism in Turkey\\\">a secular state<\\/a>, Turkey has <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Islam_in_Turkey\\\" title=\\\"Islam in Turkey\\\">a Muslim-majority<\\/a> population. <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Ankara\\\" title=\\\"Ankara\\\">Ankara<\\/a> is Turkey\'s capital and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_largest_cities_and_towns_in_Turkey\\\" title=\\\"List of largest cities and towns in Turkey\\\">second-largest city<\\/a>, while <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Istanbul\\\" title=\\\"Istanbul\\\">Istanbul<\\/a> is its largest city and economic and financial center. Other major cities include <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/%C4%B0zmir\\\" title=\\\"\\u0130zmir\\\">\\u0130zmir<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Bursa\\\" title=\\\"Bursa\\\">Bursa<\\/a>, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Antalya\\\" title=\\\"Antalya\\\">Antalya<\\/a>.<\\/p>\",\"tooltip\":0}',0,'0400$919e6af601a0f1f0f0f1a674bdfb9703:a307911d39fb871d57400a518061db89'),
(19,1731078171,2,'BE',1,0,2,'tt_content','{\"oldRecord\":{\"pages\":\"2\"},\"newRecord\":{\"pages\":\"\"}}',0,'0400$de99690a1eed29db8e051348e9df89e2:01dbc21fdb1263685b9147b3b1596ea8'),
(20,1731078196,2,'BE',1,0,2,'tt_content','{\"oldRecord\":{\"pages\":\"\"},\"newRecord\":{\"pages\":\"2\"}}',0,'0400$0a33fd8edf68dc3a291cdd9cbcddbe24:01dbc21fdb1263685b9147b3b1596ea8'),
(21,1731078344,2,'BE',1,0,1,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"description\":\"<p><strong>Australia<\\/strong>, officially the <strong>Commonwealth of Australia<\\/strong>,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-21\\\"><sup>[17]<\\/sup><\\/a> is a country comprising <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Mainland_Australia\\\" title=\\\"Mainland Australia\\\">the mainland<\\/a> of the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia_(continent)\\\" title=\\\"Australia (continent)\\\">Australian continent<\\/a>, the island of <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Tasmania\\\" title=\\\"Tasmania\\\">Tasmania<\\/a> and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_islands_of_Australia\\\" title=\\\"List of islands of Australia\\\">numerous smaller islands<\\/a>.<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-22\\\"><sup>[18]<\\/sup><\\/a> Australia has a total area of 7,688,287&nbsp;km<sup>2<\\/sup> (2,968,464&nbsp;sq&nbsp;mi), making it the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_countries_and_dependencies_by_area\\\" title=\\\"List of countries and dependencies by area\\\">sixth-largest country in the world<\\/a> and the largest country by area in <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Oceania\\\" title=\\\"Oceania\\\">Oceania<\\/a>. It is the world\'s oldest,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-23\\\"><sup>[19]<\\/sup><\\/a> flattest,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-24\\\"><sup>[20]<\\/sup><\\/a> and driest inhabited continent,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-25\\\"><sup>[21]<\\/sup><\\/a><a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-26\\\"><sup>[22]<\\/sup><\\/a> with some of the least fertile soils.<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-27\\\"><sup>[23]<\\/sup><\\/a><a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Australia#cite_note-28\\\"><sup>[24]<\\/sup><\\/a> It is a <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Megadiverse_countries\\\" title=\\\"Megadiverse countries\\\">megadiverse country<\\/a>, and its size gives it a wide variety of landscapes and climates including <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Deserts_of_Australia\\\" title=\\\"Deserts of Australia\\\">deserts<\\/a> in the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Outback\\\" title=\\\"Outback\\\">interior<\\/a> and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Forests_of_Australia\\\" title=\\\"Forests of Australia\\\">tropical rainforests<\\/a> along the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Eastern_states_of_Australia\\\" title=\\\"Eastern states of Australia\\\">coast<\\/a>.<\\/p>\"},\"newRecord\":{\"description\":\"<p><strong>Australia<\\/strong>, officially the <strong>Commonwealth of Australia<\\/strong>, is a country comprising the mainland of the Australian continent, the island of Tasmania and numerous smaller islands. Australia has a total area of 7,688,287&nbsp;km<sup>2<\\/sup> (2,968,464&nbsp;sq&nbsp;mi), making it the sixth-largest country in the world and the largest country by area in Oceania. It is the world\'s oldest, flattest, and driest inhabited continent, with some of the least fertile soils. It is a megadiverse country, and its size gives it a wide variety of landscapes and climates including deserts in the interior and tropical rainforests along the coast.<\\/p>\"}}',0,'0400$bf0999b1420f0999a66c8ca43ec85f7b:d2b7b2935ce6ff53dca8bf6e5561666f'),
(22,1731078405,2,'BE',1,0,2,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"description\":\"<p><strong>England<\\/strong> is a <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Countries_of_the_United_Kingdom\\\" title=\\\"Countries of the United Kingdom\\\">country<\\/a> that is part of the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/United_Kingdom\\\" title=\\\"United Kingdom\\\">United Kingdom<\\/a>.<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/England#cite_note-ONS_Geography_Guide-9\\\"><sup>[<\\/sup><sup>6<\\/sup><sup>]<\\/sup><\\/a> It is located on the island of <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Great_Britain\\\" title=\\\"Great Britain\\\">Great Britain<\\/a>, of which it covers about 62%, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_islands_of_England\\\" title=\\\"List of islands of England\\\">more than 100 smaller adjacent islands<\\/a>. It has land borders with <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Scotland\\\" title=\\\"Scotland\\\">Scotland<\\/a> to the north and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Wales\\\" title=\\\"Wales\\\">Wales<\\/a> to the west, and is otherwise surrounded by the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/North_Sea\\\" title=\\\"North Sea\\\">North Sea<\\/a> to the east, the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/English_Channel\\\" title=\\\"English Channel\\\">English Channel<\\/a> to the south, the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Celtic_Sea\\\" title=\\\"Celtic Sea\\\">Celtic Sea<\\/a> to the south-west, and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Irish_Sea\\\" title=\\\"Irish Sea\\\">Irish Sea<\\/a> to the west. <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Continental_Europe\\\" title=\\\"Continental Europe\\\">Continental Europe<\\/a> lies to the south-east, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Ireland\\\" title=\\\"Ireland\\\">Ireland<\\/a> to the west. At the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/2021_United_Kingdom_census\\\" title=\\\"2021 United Kingdom census\\\">2021 census<\\/a>, the population was 56,490,048.<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/England#cite_note-2021_Nomis-1\\\"><sup>[<\\/sup><sup>1<\\/sup><sup>]<\\/sup><\\/a> <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/London\\\" title=\\\"London\\\">London<\\/a> is both <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_urban_areas_in_the_United_Kingdom\\\" title=\\\"List of urban areas in the United Kingdom\\\">the largest city<\\/a> and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Capital_city\\\" title=\\\"Capital city\\\">capital<\\/a>.<\\/p>\",\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\"},\"newRecord\":{\"description\":\"<p><strong>England<\\/strong> is a country that is part of the United Kingdom. It is located on the island of Great Britain, of which it covers about 62%, and more than 100 smaller adjacent islands. It has land borders with Scotland to the north and Wales to the west, and is otherwise surrounded by the North Sea to the east, the English Channel to the south, the Celtic Sea to the south-west, and the Irish Sea to the west. Continental Europe lies to the south-east, and Ireland to the west. At the 2021 census, the population was 56,490,048. London is both the largest city and the capital.<\\/p>\",\"l10n_diffsource\":\"{\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\"}\"}}',0,'0400$203546ff822625258497530f737a6e17:deccc9582a961b981e5b191666ccddd2'),
(23,1731078454,2,'BE',1,0,3,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"description\":\"<p><strong>India<\\/strong>, officially the <strong>Republic of India<\\/strong>,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/India#cite_note-30\\\"><sup>[<\\/sup><sup>j<\\/sup><sup>]<\\/sup><\\/a><a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/India#cite_note-31\\\"><sup>[<\\/sup><sup>21<\\/sup><sup>]<\\/sup><\\/a> is a country in <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/South_Asia\\\" title=\\\"South Asia\\\">South Asia<\\/a>. It is the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_countries_and_dependencies_by_area\\\" title=\\\"\\\">seventh-largest country in the world by area<\\/a> and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_countries_by_population_(United_Nations)\\\" title=\\\"List of countries by population (United Nations)\\\">most populous country<\\/a>. Bounded by the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Indian_Ocean\\\" title=\\\"Indian Ocean\\\">Indian Ocean<\\/a> on the south, the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Arabian_Sea\\\" title=\\\"Arabian Sea\\\">Arabian Sea<\\/a> on the southwest, and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Bay_of_Bengal\\\" title=\\\"Bay of Bengal\\\">Bay of Bengal<\\/a> on the southeast, it shares land borders with <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Pakistan\\\" title=\\\"Pakistan\\\">Pakistan<\\/a> to the west;<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/India#cite_note-33\\\"><sup>[<\\/sup><sup>k<\\/sup><sup>]<\\/sup><\\/a> <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/China\\\" title=\\\"China\\\">China<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Nepal\\\" title=\\\"Nepal\\\">Nepal<\\/a>, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Bhutan\\\" title=\\\"Bhutan\\\">Bhutan<\\/a> to the north; and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Bangladesh\\\" title=\\\"Bangladesh\\\">Bangladesh<\\/a> and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Myanmar\\\" title=\\\"Myanmar\\\">Myanmar<\\/a> to the east. In the Indian Ocean, India is in the vicinity of <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Sri_Lanka\\\" title=\\\"Sri Lanka\\\">Sri Lanka<\\/a> and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Maldives\\\" title=\\\"Maldives\\\">Maldives<\\/a>; its <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Andaman_and_Nicobar_Islands\\\" title=\\\"Andaman and Nicobar Islands\\\">Andaman and Nicobar Islands<\\/a> share a maritime border with <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Thailand\\\" title=\\\"Thailand\\\">Thailand<\\/a>, Myanmar, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Indonesia\\\" title=\\\"Indonesia\\\">Indonesia<\\/a>.<\\/p>\\r\\n\\r\\n\\r\\n\\r\\n\",\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\"},\"newRecord\":{\"description\":\"<p><strong>India<\\/strong>, officially the <strong>Republic of India<\\/strong>, is a country in South Asia. It is the seventh-largest country in the world by area and the most populous country. Bounded by the Indian Ocean on the south, the Arabian Sea on the southwest, and the Bay of Bengal on the southeast, it shares land borders with Pakistan to the west; China, Nepal, and Bhutan to the north; and Bangladesh and Myanmar to the east. In the Indian Ocean, India is in the vicinity of Sri Lanka and the Maldives; its Andaman and Nicobar Islands share a maritime border with Thailand, Myanmar, and Indonesia.<\\/p>\\r\\n\\r\\n\\r\\n\\r\\n\",\"l10n_diffsource\":\"{\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\"}\"}}',0,'0400$f99507d217f52a87924099fb6a9986ea:46334a3d8ac0b8573c76c9dcd24e0ec5'),
(24,1731078592,2,'BE',1,0,4,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"description\":\"<p><strong>Mexico<\\/strong>,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Mexico#cite_note-10\\\"><sup>[<\\/sup><sup>a<\\/sup><sup>]<\\/sup><\\/a><a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Mexico#cite_note-12\\\"><sup>[<\\/sup><sup>b<\\/sup><sup>]<\\/sup><\\/a> officially the <strong>United Mexican States<\\/strong>,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Mexico#cite_note-13\\\"><sup>[<\\/sup><sup>c<\\/sup><sup>]<\\/sup><\\/a> is a country in the southern portion of <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/North_America\\\" title=\\\"North America\\\">North America<\\/a>. Covering 1,972,550&nbsp;km<sup>2<\\/sup> (761,610 sq mi),<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Mexico#cite_note-cia.gov-14\\\"><sup>[<\\/sup><sup>11<\\/sup><sup>]<\\/sup><\\/a> it is the world\'s <a class=\\\"mw-redirect\\\" href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_countries_by_area\\\" title=\\\"List of countries by area\\\">13th largest country<\\/a> by area; with a population of almost 130 million, it is the <a class=\\\"mw-redirect\\\" href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_countries_by_population\\\" title=\\\"List of countries by population\\\">10th most populous<\\/a> country and has the most <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Hispanophone#Countries\\\" title=\\\"Hispanophone\\\">Spanish speakers<\\/a> in the world.<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Mexico#cite_note-2020_Census-1\\\"><sup>[<\\/sup><sup>1<\\/sup><sup>]<\\/sup><\\/a> Mexico is a <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Constitution_of_Mexico\\\" title=\\\"Constitution of Mexico\\\">constitutional<\\/a> republic comprising <a class=\\\"mw-redirect\\\" href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Mexican_state\\\" title=\\\"Mexican state\\\">31 states<\\/a> and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Mexico_City\\\" title=\\\"Mexico City\\\">Mexico City<\\/a>, its capital and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_cities_in_Mexico\\\" title=\\\"List of cities in Mexico\\\">largest city<\\/a>, which is among the <a class=\\\"mw-redirect\\\" href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_cities_by_population\\\" title=\\\"List of cities by population\\\">world\'s most populous metropolitan areas<\\/a>. The country shares land <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Borders_of_Mexico\\\" title=\\\"Borders of Mexico\\\">borders<\\/a> <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Mexico%E2%80%93United_States_border\\\" title=\\\"Mexico\\u2013United States border\\\">with the United States<\\/a> to the north, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Guatemala%E2%80%93Mexico_border\\\" title=\\\"Guatemala\\u2013Mexico border\\\">with Guatemala<\\/a> <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Belize%E2%80%93Mexico_border\\\" title=\\\"Belize\\u2013Mexico border\\\">and Belize<\\/a> to the southeast; as well as maritime borders with the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Pacific_Ocean\\\" title=\\\"Pacific Ocean\\\">Pacific Ocean<\\/a> to the west, the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Caribbean_Sea\\\" title=\\\"Caribbean Sea\\\">Caribbean Sea<\\/a> to the southeast, and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Gulf_of_Mexico\\\" title=\\\"Gulf of Mexico\\\">Gulf of Mexico<\\/a> to the east.<\\/p>\",\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\"},\"newRecord\":{\"description\":\"<p><strong>Mexico<\\/strong>, officially the <strong>United Mexican States<\\/strong>, is a country in the southern portion of North America. Covering 1,972,550&nbsp;km<sup>2<\\/sup> (761,610 sq mi), it is the world\'s 13th largest country by area; with a population of almost 130 million, it is the 10th most populous country and has the most Spanish speakers in the world. Mexico is a constitutional republic comprising 31 states and Mexico City, its capital and largest city, which is among the world\'s most populous metropolitan areas. The country shares land borders with the United States to the north, with Guatemala and Belize to the southeast; as well as maritime borders with the Pacific Ocean to the west, the Caribbean Sea to the southeast, and the Gulf of Mexico to the east.<\\/p>\",\"l10n_diffsource\":\"{\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\"}\"}}',0,'0400$e7725017961c45ee0c71abc7a684161b:0114b4062417f901ad0d42ab5ad32ada'),
(25,1731078597,2,'BE',1,0,5,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"hidden\":0,\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"1\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$0b304f5f7d0a9664cc377eb3cbc63e44:43e143529e3c218c02c465eadd1081ac'),
(26,1731078598,2,'BE',1,0,5,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"}}',0,'0400$7004630b7661a59bd9516d441543ee98:43e143529e3c218c02c465eadd1081ac'),
(27,1731078680,2,'BE',1,0,5,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"<p><strong>Poland<\\/strong>,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Poland#cite_note-23\\\"><sup>[<\\/sup><sup>e<\\/sup><sup>]<\\/sup><\\/a> officially the <strong>Republic of Poland<\\/strong>,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Poland#cite_note-24\\\"><sup>[<\\/sup><sup>f<\\/sup><sup>]<\\/sup><\\/a> is a country in <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Central_Europe\\\" title=\\\"Central Europe\\\">Central Europe<\\/a>. It extends from the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Baltic_Sea\\\" title=\\\"Baltic Sea\\\">Baltic Sea<\\/a> in the north to the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Sudetes\\\" title=\\\"Sudetes\\\">Sudetes<\\/a> and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Carpathian_Mountains\\\" title=\\\"Carpathian Mountains\\\">Carpathian Mountains<\\/a> in the south, bordered by <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Lithuania\\\" title=\\\"Lithuania\\\">Lithuania<\\/a> and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Russia\\\" title=\\\"Russia\\\">Russia<\\/a><a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Poland#cite_note-25\\\"><sup>[<\\/sup><sup>g<\\/sup><sup>]<\\/sup><\\/a> to the northeast, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Belarus\\\" title=\\\"Belarus\\\">Belarus<\\/a> and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Ukraine\\\" title=\\\"Ukraine\\\">Ukraine<\\/a> to the east, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Slovakia\\\" title=\\\"Slovakia\\\">Slovakia<\\/a> and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Czech_Republic\\\" title=\\\"Czech Republic\\\">Czech Republic<\\/a> to the south, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Germany\\\" title=\\\"Germany\\\">Germany<\\/a> to the west. The territory is characterised by a varied landscape, diverse ecosystems, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Temperate_climate\\\" title=\\\"Temperate climate\\\">temperate transitional<\\/a> climate. Poland is composed of <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Voivodeships_of_Poland\\\" title=\\\"Voivodeships of Poland\\\">sixteen voivodeships<\\/a> and is the fifth most populous <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Member_state_of_the_European_Union\\\" title=\\\"Member state of the European Union\\\">member state of the European Union<\\/a> (EU), with over 38 million people, and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_European_countries_by_area\\\" title=\\\"List of European countries by area\\\">fifth largest EU country<\\/a> by land area, covering a combined area of 312,696&nbsp;km<sup>2<\\/sup> (120,733&nbsp;sq&nbsp;mi). The capital and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_cities_and_towns_in_Poland\\\" title=\\\"List of cities and towns in Poland\\\">largest city<\\/a> is <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Warsaw\\\" title=\\\"Warsaw\\\">Warsaw<\\/a>; other major cities include <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Krak%C3%B3w\\\" title=\\\"Krak\\u00f3w\\\">Krak\\u00f3w<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Wroc%C5%82aw\\\" title=\\\"Wroc\\u0142aw\\\">Wroc\\u0142aw<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/%C5%81%C3%B3d%C5%BA\\\" title=\\\"\\u0141\\u00f3d\\u017a\\\">\\u0141\\u00f3d\\u017a<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Pozna%C5%84\\\" title=\\\"Pozna\\u0144\\\">Pozna\\u0144<\\/a>, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Gda%C5%84sk\\\" title=\\\"Gda\\u0144sk\\\">Gda\\u0144sk<\\/a>.<\\/p>\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"synonyms\":\"Republic of Poland\",\"short_description\":\"country of Poland\",\"description\":\"<p><strong>Poland<\\/strong>, officially the <strong>Republic of Poland<\\/strong>,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Poland#cite_note-24\\\"><sup>[f]<\\/sup><\\/a> is a country in <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Central_Europe\\\" title=\\\"Central Europe\\\">Central Europe<\\/a>. It extends from the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Baltic_Sea\\\" title=\\\"Baltic Sea\\\">Baltic Sea<\\/a> in the north to the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Sudetes\\\" title=\\\"Sudetes\\\">Sudetes<\\/a> and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Carpathian_Mountains\\\" title=\\\"Carpathian Mountains\\\">Carpathian Mountains<\\/a> in the south, bordered by <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Lithuania\\\" title=\\\"Lithuania\\\">Lithuania<\\/a> and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Russia\\\" title=\\\"Russia\\\">Russia<\\/a><a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Poland#cite_note-25\\\"><sup>[g]<\\/sup><\\/a> to the northeast, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Belarus\\\" title=\\\"Belarus\\\">Belarus<\\/a> and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Ukraine\\\" title=\\\"Ukraine\\\">Ukraine<\\/a> to the east, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Slovakia\\\" title=\\\"Slovakia\\\">Slovakia<\\/a> and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Czech_Republic\\\" title=\\\"Czech Republic\\\">Czech Republic<\\/a> to the south, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Germany\\\" title=\\\"Germany\\\">Germany<\\/a> to the west. The territory is characterised by a varied landscape, diverse ecosystems, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Temperate_climate\\\" title=\\\"Temperate climate\\\">temperate transitional<\\/a> climate. Poland is composed of <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Voivodeships_of_Poland\\\" title=\\\"Voivodeships of Poland\\\">sixteen voivodeships<\\/a> and is the fifth most populous <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Member_state_of_the_European_Union\\\" title=\\\"Member state of the European Union\\\">member state of the European Union<\\/a> (EU), with over 38 million people, and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_European_countries_by_area\\\" title=\\\"List of European countries by area\\\">fifth largest EU country<\\/a> by land area, covering a combined area of 312,696&nbsp;km<sup>2<\\/sup> (120,733&nbsp;sq&nbsp;mi). The capital and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_cities_and_towns_in_Poland\\\" title=\\\"List of cities and towns in Poland\\\">largest city<\\/a> is <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Warsaw\\\" title=\\\"Warsaw\\\">Warsaw<\\/a>; other major cities include <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Krak%C3%B3w\\\" title=\\\"Krak\\u00f3w\\\">Krak\\u00f3w<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Wroc%C5%82aw\\\" title=\\\"Wroc\\u0142aw\\\">Wroc\\u0142aw<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/%C5%81%C3%B3d%C5%BA\\\" title=\\\"\\u0141\\u00f3d\\u017a\\\">\\u0141\\u00f3d\\u017a<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Pozna%C5%84\\\" title=\\\"Pozna\\u0144\\\">Pozna\\u0144<\\/a>, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Gda%C5%84sk\\\" title=\\\"Gda\\u0144sk\\\">Gda\\u0144sk<\\/a>.<\\/p>\",\"l10n_diffsource\":\"{\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\"}\"}}',0,'0400$eb19ba44d6f1d39473e0e4430e92d11d:43e143529e3c218c02c465eadd1081ac'),
(28,1731078933,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"config\":\"page = PAGE\\r\\npage.10 = TEXT\\r\\npage.10.value = <h1>in2glossar Dev Env<\\/h1>\\r\\npage.100 = CONTENT\\r\\npage.100 {\\r\\n    table = tt_content\\r\\n    select {\\r\\n        orderBy = sorting\\r\\n        where = {#colPos}=0\\r\\n    }\\r\\n}\\r\\n\"},\"newRecord\":{\"config\":\"page = PAGE\\r\\npage.10 = TEXT\\r\\npage.10.value = <h1>in2glossar Dev Env<\\/h1>\\r\\npage.100 = CONTENT\\r\\npage.100 {\\r\\n    table = tt_content\\r\\n    select {\\r\\n        orderBy = sorting\\r\\n        where = {#colPos}=0\\r\\n    }\\r\\n}\\r\\nconfig.contentObjectExceptionHandler = 0\"}}',0,'0400$ddd7aa2b3e2ba16a5f84395f6d556978:35af6288617af54964e77af08c30949a'),
(29,1731079219,2,'BE',1,0,1,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"synonyms\":\"\",\"short_description\":\"\"},\"newRecord\":{\"synonyms\":\"Commonwealth of Australia\",\"short_description\":\"Australian continent\"}}',0,'0400$99f8b5e5a077e3539b7947ae492fe619:d2b7b2935ce6ff53dca8bf6e5561666f'),
(30,1731079238,2,'BE',1,0,2,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"synonyms\":\"\",\"short_description\":\"\"},\"newRecord\":{\"synonyms\":\"United Kingdom\",\"short_description\":\"Great Britain\"}}',0,'0400$83c6015d7c79972b3e9d56e8bfb61896:deccc9582a961b981e5b191666ccddd2'),
(31,1731079253,2,'BE',1,0,3,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"synonyms\":\"\",\"short_description\":\"\"},\"newRecord\":{\"synonyms\":\"Republic of India\",\"short_description\":\"South Asia\"}}',0,'0400$6c9b40e5ea3f0cae76d2da31a63eb703:46334a3d8ac0b8573c76c9dcd24e0ec5'),
(32,1731079285,2,'BE',1,0,4,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"synonyms\":\"\",\"short_description\":\"\"},\"newRecord\":{\"synonyms\":\"United Mexican States\",\"short_description\":\"southern portion of North America\"}}',0,'0400$4710603eddeadf0672bbdf40f911f45a:0114b4062417f901ad0d42ab5ad32ada'),
(33,1731079311,2,'BE',1,0,6,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"<p><strong>Romania<\\/strong><a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Romania#cite_note-12\\\"><sup>[<\\/sup><sup>a<\\/sup><sup>]<\\/sup><\\/a> is a country located at the crossroads of <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Central_Europe\\\" title=\\\"Central Europe\\\">Central<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Eastern_Europe\\\" title=\\\"Eastern Europe\\\">Eastern<\\/a>, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Southeast_Europe\\\" title=\\\"Southeast Europe\\\">Southeast Europe<\\/a>.<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Romania#cite_note-13\\\"><sup>[<\\/sup><sup>12<\\/sup><sup>]<\\/sup><\\/a><a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Romania#cite_note-14\\\"><sup>[<\\/sup><sup>13<\\/sup><sup>]<\\/sup><\\/a><a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Romania#cite_note-15\\\"><sup>[<\\/sup><sup>14<\\/sup><sup>]<\\/sup><\\/a> It borders <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Ukraine\\\" title=\\\"Ukraine\\\">Ukraine<\\/a> to the north and east, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Hungary\\\" title=\\\"Hungary\\\">Hungary<\\/a> to the west, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Serbia\\\" title=\\\"Serbia\\\">Serbia<\\/a> to the southwest, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Bulgaria\\\" title=\\\"Bulgaria\\\">Bulgaria<\\/a> to the south, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Moldova\\\" title=\\\"Moldova\\\">Moldova<\\/a> to the east, and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Black_Sea\\\" title=\\\"Black Sea\\\">Black Sea<\\/a> to the southeast. It has a mainly <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Continental_climate\\\" title=\\\"Continental climate\\\">continental climate<\\/a>, and an area of 238,397&nbsp;km<sup>2<\\/sup> (92,046&nbsp;sq&nbsp;mi) with a population of 19 million people (2023). Romania is the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_European_countries_by_area\\\" title=\\\"List of European countries by area\\\">twelfth-largest country<\\/a> in Europe and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_European_Union_member_states_by_population\\\" title=\\\"List of European Union member states by population\\\">sixth-most populous<\\/a> member state of the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/European_Union\\\" title=\\\"European Union\\\">European Union<\\/a>. Europe\'s second-longest river, the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Danube\\\" title=\\\"Danube\\\">Danube<\\/a>, empties into the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Danube_Delta\\\" title=\\\"Danube Delta\\\">Danube Delta<\\/a> in the southeast of the country. The <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Carpathian_Mountains\\\" title=\\\"\\\">Carpathian Mountains<\\/a> cross Romania from the north to the southwest and include <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Moldoveanu_Peak\\\" title=\\\"Moldoveanu Peak\\\">Moldoveanu Peak<\\/a>, at an altitude of 2,544&nbsp;m (8,346&nbsp;ft).<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Romania#cite_note-16\\\"><sup>[<\\/sup><sup>15<\\/sup><sup>]<\\/sup><\\/a> Romania\'s capital and largest city is <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Bucharest\\\" title=\\\"Bucharest\\\">Bucharest<\\/a>. Other major <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Urban_area\\\" title=\\\"Urban area\\\">urban centers<\\/a> include <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Cluj-Napoca\\\" title=\\\"Cluj-Napoca\\\">Cluj-Napoca<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Timi%C8%99oara\\\" title=\\\"Timi\\u0219oara\\\">Timi\\u0219oara<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Ia%C8%99i\\\" title=\\\"Ia\\u0219i\\\">Ia\\u0219i<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Constan%C8%9Ba\\\" title=\\\"Constan\\u021ba\\\">Constan\\u021ba<\\/a> and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Bra%C8%99ov\\\" title=\\\"Bra\\u0219ov\\\">Bra\\u0219ov<\\/a>.<\\/p>\",\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\"},\"newRecord\":{\"synonyms\":\"Romania\",\"short_description\":\"Romania\",\"description\":\"<p><strong>Romania<\\/strong><a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Romania#cite_note-12\\\"><sup>[a]<\\/sup><\\/a> is a country located at the crossroads of <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Central_Europe\\\" title=\\\"Central Europe\\\">Central<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Eastern_Europe\\\" title=\\\"Eastern Europe\\\">Eastern<\\/a>, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Southeast_Europe\\\" title=\\\"Southeast Europe\\\">Southeast Europe<\\/a>.<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Romania#cite_note-13\\\"><sup>[12]<\\/sup><\\/a><a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Romania#cite_note-14\\\"><sup>[13]<\\/sup><\\/a><a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Romania#cite_note-15\\\"><sup>[14]<\\/sup><\\/a> It borders <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Ukraine\\\" title=\\\"Ukraine\\\">Ukraine<\\/a> to the north and east, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Hungary\\\" title=\\\"Hungary\\\">Hungary<\\/a> to the west, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Serbia\\\" title=\\\"Serbia\\\">Serbia<\\/a> to the southwest, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Bulgaria\\\" title=\\\"Bulgaria\\\">Bulgaria<\\/a> to the south, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Moldova\\\" title=\\\"Moldova\\\">Moldova<\\/a> to the east, and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Black_Sea\\\" title=\\\"Black Sea\\\">Black Sea<\\/a> to the southeast. It has a mainly <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Continental_climate\\\" title=\\\"Continental climate\\\">continental climate<\\/a>, and an area of 238,397&nbsp;km<sup>2<\\/sup> (92,046&nbsp;sq&nbsp;mi) with a population of 19 million people (2023). Romania is the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_European_countries_by_area\\\" title=\\\"List of European countries by area\\\">twelfth-largest country<\\/a> in Europe and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_European_Union_member_states_by_population\\\" title=\\\"List of European Union member states by population\\\">sixth-most populous<\\/a> member state of the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/European_Union\\\" title=\\\"European Union\\\">European Union<\\/a>. Europe\'s second-longest river, the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Danube\\\" title=\\\"Danube\\\">Danube<\\/a>, empties into the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Danube_Delta\\\" title=\\\"Danube Delta\\\">Danube Delta<\\/a> in the southeast of the country. The <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Carpathian_Mountains\\\" title=\\\"\\\">Carpathian Mountains<\\/a> cross Romania from the north to the southwest and include <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Moldoveanu_Peak\\\" title=\\\"Moldoveanu Peak\\\">Moldoveanu Peak<\\/a>, at an altitude of 2,544&nbsp;m (8,346&nbsp;ft).<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Romania#cite_note-16\\\"><sup>[15]<\\/sup><\\/a> Romania\'s capital and largest city is <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Bucharest\\\" title=\\\"Bucharest\\\">Bucharest<\\/a>. Other major <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Urban_area\\\" title=\\\"Urban area\\\">urban centers<\\/a> include <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Cluj-Napoca\\\" title=\\\"Cluj-Napoca\\\">Cluj-Napoca<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Timi%C8%99oara\\\" title=\\\"Timi\\u0219oara\\\">Timi\\u0219oara<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Ia%C8%99i\\\" title=\\\"Ia\\u0219i\\\">Ia\\u0219i<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Constan%C8%9Ba\\\" title=\\\"Constan\\u021ba\\\">Constan\\u021ba<\\/a> and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Bra%C8%99ov\\\" title=\\\"Bra\\u0219ov\\\">Bra\\u0219ov<\\/a>.<\\/p>\",\"l10n_diffsource\":\"{\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\"}\"}}',0,'0400$186657da46a25547b2e4c5fe0b93a551:25ba7be3f8552fa129791269cd55d6e5'),
(34,1731079336,2,'BE',1,0,7,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"<p><strong>Turkey<\\/strong>,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Turkey#cite_note-12\\\"><sup>[<\\/sup><sup>a<\\/sup><sup>]<\\/sup><\\/a> officially the <strong>Republic of T\\u00fcrkiye<\\/strong>,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Turkey#cite_note-13\\\"><sup>[<\\/sup><sup>b<\\/sup><sup>]<\\/sup><\\/a> is a country mainly located in <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Anatolia\\\" title=\\\"Anatolia\\\">Anatolia<\\/a> in <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/West_Asia\\\" title=\\\"West Asia\\\">West Asia<\\/a>, with a smaller part called <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/East_Thrace\\\" title=\\\"East Thrace\\\">East Thrace<\\/a> in <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Southeast_Europe\\\" title=\\\"Southeast Europe\\\">Southeast Europe<\\/a>. It borders the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Black_Sea\\\" title=\\\"Black Sea\\\">Black Sea<\\/a> to the north; <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Georgia_(country)\\\" title=\\\"Georgia (country)\\\">Georgia<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Armenia\\\" title=\\\"Armenia\\\">Armenia<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Azerbaijan\\\" title=\\\"Azerbaijan\\\">Azerbaijan<\\/a>, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Iran\\\" title=\\\"Iran\\\">Iran<\\/a> to the east; <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Iraq\\\" title=\\\"Iraq\\\">Iraq<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Syria\\\" title=\\\"Syria\\\">Syria<\\/a>, and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Mediterranean_Sea\\\" title=\\\"Mediterranean Sea\\\">Mediterranean Sea<\\/a> to the south; and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Aegean_Sea\\\" title=\\\"Aegean Sea\\\">Aegean Sea<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Greece\\\" title=\\\"Greece\\\">Greece<\\/a>, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Bulgaria\\\" title=\\\"Bulgaria\\\">Bulgaria<\\/a> to the west. Turkey is home to over 85 million people; most are ethnic <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Turkish_people\\\" title=\\\"Turkish people\\\">Turks<\\/a>, while ethnic <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Kurds\\\" title=\\\"Kurds\\\">Kurds<\\/a> are the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Minorities_in_Turkey\\\" title=\\\"Minorities in Turkey\\\">largest ethnic minority<\\/a>.<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Turkey#cite_note-cia-5\\\"><sup>[<\\/sup><sup>5<\\/sup><sup>]<\\/sup><\\/a> Officially <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Secularism_in_Turkey\\\" title=\\\"Secularism in Turkey\\\">a secular state<\\/a>, Turkey has <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Islam_in_Turkey\\\" title=\\\"Islam in Turkey\\\">a Muslim-majority<\\/a> population. <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Ankara\\\" title=\\\"Ankara\\\">Ankara<\\/a> is Turkey\'s capital and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_largest_cities_and_towns_in_Turkey\\\" title=\\\"List of largest cities and towns in Turkey\\\">second-largest city<\\/a>, while <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Istanbul\\\" title=\\\"Istanbul\\\">Istanbul<\\/a> is its largest city and economic and financial center. Other major cities include <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/%C4%B0zmir\\\" title=\\\"\\u0130zmir\\\">\\u0130zmir<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Bursa\\\" title=\\\"Bursa\\\">Bursa<\\/a>, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Antalya\\\" title=\\\"Antalya\\\">Antalya<\\/a>.<\\/p>\",\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\"},\"newRecord\":{\"synonyms\":\"Republic of T\\u00fcrkiye\",\"short_description\":\"West Asia\",\"description\":\"<p><strong>Turkey<\\/strong>,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Turkey#cite_note-12\\\"><sup>[a]<\\/sup><\\/a> officially the <strong>Republic of T\\u00fcrkiye<\\/strong>,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Turkey#cite_note-13\\\"><sup>[b]<\\/sup><\\/a> is a country mainly located in <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Anatolia\\\" title=\\\"Anatolia\\\">Anatolia<\\/a> in <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/West_Asia\\\" title=\\\"West Asia\\\">West Asia<\\/a>, with a smaller part called <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/East_Thrace\\\" title=\\\"East Thrace\\\">East Thrace<\\/a> in <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Southeast_Europe\\\" title=\\\"Southeast Europe\\\">Southeast Europe<\\/a>. It borders the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Black_Sea\\\" title=\\\"Black Sea\\\">Black Sea<\\/a> to the north; <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Georgia_(country)\\\" title=\\\"Georgia (country)\\\">Georgia<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Armenia\\\" title=\\\"Armenia\\\">Armenia<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Azerbaijan\\\" title=\\\"Azerbaijan\\\">Azerbaijan<\\/a>, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Iran\\\" title=\\\"Iran\\\">Iran<\\/a> to the east; <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Iraq\\\" title=\\\"Iraq\\\">Iraq<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Syria\\\" title=\\\"Syria\\\">Syria<\\/a>, and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Mediterranean_Sea\\\" title=\\\"Mediterranean Sea\\\">Mediterranean Sea<\\/a> to the south; and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Aegean_Sea\\\" title=\\\"Aegean Sea\\\">Aegean Sea<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Greece\\\" title=\\\"Greece\\\">Greece<\\/a>, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Bulgaria\\\" title=\\\"Bulgaria\\\">Bulgaria<\\/a> to the west. Turkey is home to over 85 million people; most are ethnic <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Turkish_people\\\" title=\\\"Turkish people\\\">Turks<\\/a>, while ethnic <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Kurds\\\" title=\\\"Kurds\\\">Kurds<\\/a> are the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Minorities_in_Turkey\\\" title=\\\"Minorities in Turkey\\\">largest ethnic minority<\\/a>.<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Turkey#cite_note-cia-5\\\"><sup>[5]<\\/sup><\\/a> Officially <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Secularism_in_Turkey\\\" title=\\\"Secularism in Turkey\\\">a secular state<\\/a>, Turkey has <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Islam_in_Turkey\\\" title=\\\"Islam in Turkey\\\">a Muslim-majority<\\/a> population. <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Ankara\\\" title=\\\"Ankara\\\">Ankara<\\/a> is Turkey\'s capital and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_largest_cities_and_towns_in_Turkey\\\" title=\\\"List of largest cities and towns in Turkey\\\">second-largest city<\\/a>, while <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Istanbul\\\" title=\\\"Istanbul\\\">Istanbul<\\/a> is its largest city and economic and financial center. Other major cities include <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/%C4%B0zmir\\\" title=\\\"\\u0130zmir\\\">\\u0130zmir<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Bursa\\\" title=\\\"Bursa\\\">Bursa<\\/a>, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Antalya\\\" title=\\\"Antalya\\\">Antalya<\\/a>.<\\/p>\",\"l10n_diffsource\":\"{\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\"}\"}}',0,'0400$6f27c95394353a72a67a270ef53c8e8f:a307911d39fb871d57400a518061db89'),
(35,1731080337,1,'BE',1,0,4,'pages','{\"uid\":4,\"pid\":1,\"tstamp\":1731080337,\"crdate\":1731080337,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":64,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Standard Content\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"lastUpdated\":0,\"newUntil\":0,\"slug\":\"\\/standard-content\"}',0,'0400$1973a60afa92a8654b1445cf7012b753:412add0b3eb6ec8f1cb6710aea92e21e'),
(36,1731080340,2,'BE',1,0,4,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$ef7ac9e4f8a4da9797e5e415d2538c55:412add0b3eb6ec8f1cb6710aea92e21e'),
(37,1731080395,1,'BE',1,0,3,'tt_content','{\"uid\":3,\"rowDescription\":\"\",\"pid\":2,\"tstamp\":1731080395,\"crdate\":1731080395,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"textpic\",\"header\":\"The fiith Continent\",\"header_position\":\"\",\"bodytext\":\"<p>Have you ever been to australia?<\\/p>\",\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"date\":0,\"tx_in2glossar_exclude\":0}',0,'0400$157163acb64de95e17a2c1f0a195a75a:b92300cfb5d1d3645c9cb212a7f56c1f'),
(38,1731080431,3,'BE',1,0,1,'tt_content','{\"oldPageId\":1,\"newPageId\":4,\"oldData\":{\"header\":\"Test cases\",\"pid\":1,\"event_pid\":1,\"t3ver_state\":0},\"newData\":{\"tstamp\":1731080431,\"pid\":4,\"sorting\":256}}',0,'0400$e33317fa0a54140cada9ea4ecb3596a3:7fa2c035f26826fe83eeecaaeddc4d40'),
(39,1731080431,2,'BE',1,0,1,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"pages\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"accessibility_title\\\":\\\"\\\",\\\"accessibility_bypass\\\":\\\"\\\",\\\"accessibility_bypass_text\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tx_in2glossar_exclude\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\"}\"}}',0,'0400$f66546216031f08bf95c2d22bce4302a:7fa2c035f26826fe83eeecaaeddc4d40'),
(40,1731080457,3,'BE',1,0,1,'tt_content','{\"oldPageId\":4,\"newPageId\":1,\"oldData\":{\"header\":\"Test cases\",\"pid\":4,\"event_pid\":4,\"t3ver_state\":0},\"newData\":{\"tstamp\":1731080457,\"pid\":1,\"sorting\":256}}',0,'0400$a5f80e9eac34bc8dea31fc02ae9c1cbb:7fa2c035f26826fe83eeecaaeddc4d40'),
(41,1731080466,3,'BE',1,0,3,'tt_content','{\"oldPageId\":2,\"newPageId\":4,\"oldData\":{\"header\":\"The fiith Continent\",\"pid\":2,\"event_pid\":2,\"t3ver_state\":0},\"newData\":{\"tstamp\":1731080466,\"pid\":4,\"sorting\":256}}',0,'0400$9b199c5e9682e973691f455b8c0be2fc:b92300cfb5d1d3645c9cb212a7f56c1f'),
(42,1731080466,2,'BE',1,0,3,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\"}\"}}',0,'0400$26995d94084249f22d3982bc9dd722a3:b92300cfb5d1d3645c9cb212a7f56c1f'),
(43,1731080493,2,'BE',1,0,3,'tt_content','{\"oldRecord\":{\"bodytext\":\"<p>Have you ever been to australia?<\\/p>\",\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\"}\"},\"newRecord\":{\"bodytext\":\"<p>Have you ever been to Australia?<\\/p>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"imagewidth\\\":\\\"\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageborder\\\":\\\"\\\",\\\"imageorient\\\":\\\"\\\",\\\"imagecols\\\":\\\"\\\",\\\"image_zoom\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tx_in2glossar_exclude\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$fc98f6d4a69c3e449175c3cc2068619e:b92300cfb5d1d3645c9cb212a7f56c1f'),
(44,1731080590,2,'BE',1,0,1,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"tooltip\":0},\"newRecord\":{\"tooltip\":\"1\"}}',0,'0400$f7157a989ab685fa3edaf15b30a3d3e4:d2b7b2935ce6ff53dca8bf6e5561666f'),
(45,1731322606,2,'BE',1,0,5,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"description\":\"<p><strong>Poland<\\/strong>, officially the <strong>Republic of Poland<\\/strong>,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Poland#cite_note-24\\\"><sup>[f]<\\/sup><\\/a> is a country in <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Central_Europe\\\" title=\\\"Central Europe\\\">Central Europe<\\/a>. It extends from the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Baltic_Sea\\\" title=\\\"Baltic Sea\\\">Baltic Sea<\\/a> in the north to the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Sudetes\\\" title=\\\"Sudetes\\\">Sudetes<\\/a> and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Carpathian_Mountains\\\" title=\\\"Carpathian Mountains\\\">Carpathian Mountains<\\/a> in the south, bordered by <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Lithuania\\\" title=\\\"Lithuania\\\">Lithuania<\\/a> and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Russia\\\" title=\\\"Russia\\\">Russia<\\/a><a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Poland#cite_note-25\\\"><sup>[g]<\\/sup><\\/a> to the northeast, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Belarus\\\" title=\\\"Belarus\\\">Belarus<\\/a> and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Ukraine\\\" title=\\\"Ukraine\\\">Ukraine<\\/a> to the east, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Slovakia\\\" title=\\\"Slovakia\\\">Slovakia<\\/a> and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Czech_Republic\\\" title=\\\"Czech Republic\\\">Czech Republic<\\/a> to the south, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Germany\\\" title=\\\"Germany\\\">Germany<\\/a> to the west. The territory is characterised by a varied landscape, diverse ecosystems, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Temperate_climate\\\" title=\\\"Temperate climate\\\">temperate transitional<\\/a> climate. Poland is composed of <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Voivodeships_of_Poland\\\" title=\\\"Voivodeships of Poland\\\">sixteen voivodeships<\\/a> and is the fifth most populous <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Member_state_of_the_European_Union\\\" title=\\\"Member state of the European Union\\\">member state of the European Union<\\/a> (EU), with over 38 million people, and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_European_countries_by_area\\\" title=\\\"List of European countries by area\\\">fifth largest EU country<\\/a> by land area, covering a combined area of 312,696&nbsp;km<sup>2<\\/sup> (120,733&nbsp;sq&nbsp;mi). The capital and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_cities_and_towns_in_Poland\\\" title=\\\"List of cities and towns in Poland\\\">largest city<\\/a> is <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Warsaw\\\" title=\\\"Warsaw\\\">Warsaw<\\/a>; other major cities include <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Krak%C3%B3w\\\" title=\\\"Krak\\u00f3w\\\">Krak\\u00f3w<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Wroc%C5%82aw\\\" title=\\\"Wroc\\u0142aw\\\">Wroc\\u0142aw<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/%C5%81%C3%B3d%C5%BA\\\" title=\\\"\\u0141\\u00f3d\\u017a\\\">\\u0141\\u00f3d\\u017a<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Pozna%C5%84\\\" title=\\\"Pozna\\u0144\\\">Pozna\\u0144<\\/a>, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Gda%C5%84sk\\\" title=\\\"Gda\\u0144sk\\\">Gda\\u0144sk<\\/a>.<\\/p>\"},\"newRecord\":{\"description\":\"<p><strong>Poland<\\/strong>, officially the <strong>Republic of Poland<\\/strong>, is a country in Central Europe. It extends from the Baltic Sea in the north to the Sudetes and Carpathian Mountains in the south, bordered by Lithuania and Russia to the northeast, Belarus and Ukraine to the east, Slovakia and the Czech Republic to the south, and Germany to the west. The territory is characterised by a varied landscape, diverse ecosystems, and temperate transitional climate. Poland is composed of sixteen voivodeships and is the fifth most populous member state of the European Union (EU), with over 38 million people, and the fifth largest EU country by land area, covering a combined area of 312,696&nbsp;km<sup>2<\\/sup> (120,733&nbsp;sq&nbsp;mi). The capital and largest city is Warsaw; other major cities include Krak\\u00f3w, Wroc\\u0142aw, \\u0141\\u00f3d\\u017a, Pozna\\u0144, and Gda\\u0144sk.<\\/p>\"}}',0,'0400$a396f29a54906c77a4357c7516370888:43e143529e3c218c02c465eadd1081ac'),
(46,1731322668,2,'BE',1,0,6,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"description\":\"<p><strong>Romania<\\/strong><a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Romania#cite_note-12\\\"><sup>[a]<\\/sup><\\/a> is a country located at the crossroads of <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Central_Europe\\\" title=\\\"Central Europe\\\">Central<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Eastern_Europe\\\" title=\\\"Eastern Europe\\\">Eastern<\\/a>, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Southeast_Europe\\\" title=\\\"Southeast Europe\\\">Southeast Europe<\\/a>.<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Romania#cite_note-13\\\"><sup>[12]<\\/sup><\\/a><a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Romania#cite_note-14\\\"><sup>[13]<\\/sup><\\/a><a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Romania#cite_note-15\\\"><sup>[14]<\\/sup><\\/a> It borders <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Ukraine\\\" title=\\\"Ukraine\\\">Ukraine<\\/a> to the north and east, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Hungary\\\" title=\\\"Hungary\\\">Hungary<\\/a> to the west, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Serbia\\\" title=\\\"Serbia\\\">Serbia<\\/a> to the southwest, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Bulgaria\\\" title=\\\"Bulgaria\\\">Bulgaria<\\/a> to the south, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Moldova\\\" title=\\\"Moldova\\\">Moldova<\\/a> to the east, and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Black_Sea\\\" title=\\\"Black Sea\\\">Black Sea<\\/a> to the southeast. It has a mainly <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Continental_climate\\\" title=\\\"Continental climate\\\">continental climate<\\/a>, and an area of 238,397&nbsp;km<sup>2<\\/sup> (92,046&nbsp;sq&nbsp;mi) with a population of 19 million people (2023). Romania is the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_European_countries_by_area\\\" title=\\\"List of European countries by area\\\">twelfth-largest country<\\/a> in Europe and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_European_Union_member_states_by_population\\\" title=\\\"List of European Union member states by population\\\">sixth-most populous<\\/a> member state of the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/European_Union\\\" title=\\\"European Union\\\">European Union<\\/a>. Europe\'s second-longest river, the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Danube\\\" title=\\\"Danube\\\">Danube<\\/a>, empties into the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Danube_Delta\\\" title=\\\"Danube Delta\\\">Danube Delta<\\/a> in the southeast of the country. The <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Carpathian_Mountains\\\" title=\\\"\\\">Carpathian Mountains<\\/a> cross Romania from the north to the southwest and include <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Moldoveanu_Peak\\\" title=\\\"Moldoveanu Peak\\\">Moldoveanu Peak<\\/a>, at an altitude of 2,544&nbsp;m (8,346&nbsp;ft).<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Romania#cite_note-16\\\"><sup>[15]<\\/sup><\\/a> Romania\'s capital and largest city is <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Bucharest\\\" title=\\\"Bucharest\\\">Bucharest<\\/a>. Other major <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Urban_area\\\" title=\\\"Urban area\\\">urban centers<\\/a> include <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Cluj-Napoca\\\" title=\\\"Cluj-Napoca\\\">Cluj-Napoca<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Timi%C8%99oara\\\" title=\\\"Timi\\u0219oara\\\">Timi\\u0219oara<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Ia%C8%99i\\\" title=\\\"Ia\\u0219i\\\">Ia\\u0219i<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Constan%C8%9Ba\\\" title=\\\"Constan\\u021ba\\\">Constan\\u021ba<\\/a> and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Bra%C8%99ov\\\" title=\\\"Bra\\u0219ov\\\">Bra\\u0219ov<\\/a>.<\\/p>\"},\"newRecord\":{\"description\":\"<p><strong>Romania<\\/strong> is a country located at the crossroads of Central, Eastern, and Southeast Europe. It borders Ukraine to the north and east, Hungary to the west, Serbia to the southwest, Bulgaria to the south, Moldova to the east, and the Black Sea to the southeast. It has a mainly continental climate, and an area of 238,397&nbsp;km<sup>2<\\/sup> (92,046&nbsp;sq&nbsp;mi) with a population of 19 million people (2023). Romania is the twelfth-largest country in Europe and the sixth-most populous member state of the European Union. Europe\'s second-longest river, the Danube, empties into the Danube Delta in the southeast of the country. The Carpathian Mountains cross Romania from the north to the southwest and include Moldoveanu Peak, at an altitude of 2,544&nbsp;m (8,346&nbsp;ft). Romania\'s capital and largest city is Bucharest. Other major urban centers include Cluj-Napoca, Timi\\u0219oara, Ia\\u0219i, Constan\\u021ba and Bra\\u0219ov.<\\/p>\"}}',0,'0400$5e72ac968e3796ccfab112e4f49896fc:25ba7be3f8552fa129791269cd55d6e5'),
(47,1731322745,2,'BE',1,0,7,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"description\":\"<p><strong>Turkey<\\/strong>,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Turkey#cite_note-12\\\"><sup>[a]<\\/sup><\\/a> officially the <strong>Republic of T\\u00fcrkiye<\\/strong>,<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Turkey#cite_note-13\\\"><sup>[b]<\\/sup><\\/a> is a country mainly located in <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Anatolia\\\" title=\\\"Anatolia\\\">Anatolia<\\/a> in <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/West_Asia\\\" title=\\\"West Asia\\\">West Asia<\\/a>, with a smaller part called <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/East_Thrace\\\" title=\\\"East Thrace\\\">East Thrace<\\/a> in <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Southeast_Europe\\\" title=\\\"Southeast Europe\\\">Southeast Europe<\\/a>. It borders the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Black_Sea\\\" title=\\\"Black Sea\\\">Black Sea<\\/a> to the north; <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Georgia_(country)\\\" title=\\\"Georgia (country)\\\">Georgia<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Armenia\\\" title=\\\"Armenia\\\">Armenia<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Azerbaijan\\\" title=\\\"Azerbaijan\\\">Azerbaijan<\\/a>, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Iran\\\" title=\\\"Iran\\\">Iran<\\/a> to the east; <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Iraq\\\" title=\\\"Iraq\\\">Iraq<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Syria\\\" title=\\\"Syria\\\">Syria<\\/a>, and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Mediterranean_Sea\\\" title=\\\"Mediterranean Sea\\\">Mediterranean Sea<\\/a> to the south; and the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Aegean_Sea\\\" title=\\\"Aegean Sea\\\">Aegean Sea<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Greece\\\" title=\\\"Greece\\\">Greece<\\/a>, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Bulgaria\\\" title=\\\"Bulgaria\\\">Bulgaria<\\/a> to the west. Turkey is home to over 85 million people; most are ethnic <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Turkish_people\\\" title=\\\"Turkish people\\\">Turks<\\/a>, while ethnic <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Kurds\\\" title=\\\"Kurds\\\">Kurds<\\/a> are the <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Minorities_in_Turkey\\\" title=\\\"Minorities in Turkey\\\">largest ethnic minority<\\/a>.<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Turkey#cite_note-cia-5\\\"><sup>[5]<\\/sup><\\/a> Officially <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Secularism_in_Turkey\\\" title=\\\"Secularism in Turkey\\\">a secular state<\\/a>, Turkey has <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Islam_in_Turkey\\\" title=\\\"Islam in Turkey\\\">a Muslim-majority<\\/a> population. <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Ankara\\\" title=\\\"Ankara\\\">Ankara<\\/a> is Turkey\'s capital and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/List_of_largest_cities_and_towns_in_Turkey\\\" title=\\\"List of largest cities and towns in Turkey\\\">second-largest city<\\/a>, while <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Istanbul\\\" title=\\\"Istanbul\\\">Istanbul<\\/a> is its largest city and economic and financial center. Other major cities include <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/%C4%B0zmir\\\" title=\\\"\\u0130zmir\\\">\\u0130zmir<\\/a>, <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Bursa\\\" title=\\\"Bursa\\\">Bursa<\\/a>, and <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Antalya\\\" title=\\\"Antalya\\\">Antalya<\\/a>.<\\/p>\"},\"newRecord\":{\"description\":\"<p><strong>Turkey<\\/strong>, officially the <strong>Republic of T\\u00fcrkiye,<\\/strong> is a country mainly located in Anatolia in West Asia, with a smaller part called East Thrace in Southeast Europe. It borders the Black Sea to the north; Georgia, Armenia, Azerbaijan, and Iran to the east; Iraq, Syria, and the Mediterranean Sea to the south; and the Aegean Sea, Greece, and Bulgaria to the west. Turkey is home to over 85 million people; most are ethnic Turks, while ethnic Kurds are the largest ethnic minority. Officially a secular state, Turkey has a Muslim-majority population. Ankara is Turkey\'s capital and second-largest city, while Istanbul is its largest city and economic and financial center. Other major cities include \\u0130zmir, Bursa, and Antalya.<\\/p>\"}}',0,'0400$32fe54ab6f07ae63de00279922ceed29:a307911d39fb871d57400a518061db89'),
(48,1731322802,1,'BE',1,0,8,'tx_in2glossar_domain_model_definition','{\"uid\":8,\"pid\":2,\"tstamp\":1731322802,\"crdate\":1731322802,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\",\"tooltip\":0}',0,'0400$0c7369625f13391df85a5d3c3b838f48:fc83d36bec4dc88934c89082f9984c6c'),
(49,1731322820,2,'BE',1,0,1,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"tooltip\":1},\"newRecord\":{\"tooltip\":\"0\"}}',0,'0400$8f0cc935eba0e9487df7a3a1e99515aa:d2b7b2935ce6ff53dca8bf6e5561666f'),
(50,1731322903,2,'BE',1,0,8,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\",\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\"},\"newRecord\":{\"word\":\"USA\",\"synonyms\":\"United States of America\",\"short_description\":\"America\",\"description\":\"<p>The <strong>United States of America<\\/strong> (<strong>USA<\\/strong>), commonly known as the <strong>United States<\\/strong> (<strong>U.S.<\\/strong>) or <strong>America<\\/strong>, is a country primarily located in North America. It is a federal union of 50 states and a federal capital district, Washington, D.C. The 48 contiguous states border Canada to the north and Mexico to the south, with the states of Alaska to the northwest and the archipelagic Hawaii in the Pacific Ocean. The United States also asserts sovereignty over five major island territories and various uninhabited islands. The country has the world\'s third-largest land area, largest exclusive economic zone, and third-largest population, exceeding 334 million. Its three largest metropolitan areas are New York, Los Angeles, and Chicago, and its three most populous states are California, Texas, and Florida.<\\/p>\",\"l10n_diffsource\":\"{\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\"}\"}}',0,'0400$f686576e71119da15c9c62aaae9961e6:fc83d36bec4dc88934c89082f9984c6c'),
(51,1731322919,2,'BE',1,0,8,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"synonyms\":\"United States of America\",\"short_description\":\"America\"},\"newRecord\":{\"synonyms\":\"\",\"short_description\":\"\"}}',0,'0400$82f3e934c34a5099b2ecfc8e6f8400c9:fc83d36bec4dc88934c89082f9984c6c'),
(52,1731322973,2,'BE',1,0,8,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"synonyms\":\"\"},\"newRecord\":{\"synonyms\":\"United States of America\"}}',0,'0400$9c0f9e76ed2646edd0e3659c935951bb:fc83d36bec4dc88934c89082f9984c6c'),
(53,1731323127,2,'BE',1,0,8,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"short_description\":\"\"},\"newRecord\":{\"short_description\":\"America\"}}',0,'0400$7471ae4861e2618612b61ce745acfcc3:fc83d36bec4dc88934c89082f9984c6c'),
(54,1731323281,2,'BE',1,0,8,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"description\":\"<p>The <strong>United States of America<\\/strong> (<strong>USA<\\/strong>), commonly known as the <strong>United States<\\/strong> (<strong>U.S.<\\/strong>) or <strong>America<\\/strong>, is a country primarily located in North America. It is a federal union of 50 states and a federal capital district, Washington, D.C. The 48 contiguous states border Canada to the north and Mexico to the south, with the states of Alaska to the northwest and the archipelagic Hawaii in the Pacific Ocean. The United States also asserts sovereignty over five major island territories and various uninhabited islands. The country has the world\'s third-largest land area, largest exclusive economic zone, and third-largest population, exceeding 334 million. Its three largest metropolitan areas are New York, Los Angeles, and Chicago, and its three most populous states are California, Texas, and Florida.<\\/p>\"},\"newRecord\":{\"description\":\"\"}}',0,'0400$0e6aff74a330de5e7bc63965d25bcb1c:fc83d36bec4dc88934c89082f9984c6c'),
(55,1731323302,2,'BE',1,0,8,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"short_description\":\"America\",\"description\":\"\"},\"newRecord\":{\"short_description\":\"\",\"description\":\"<p>The <strong>United States of America<\\/strong> (<strong>USA<\\/strong>), commonly known as the <strong>United States<\\/strong> (<strong>U.S.<\\/strong>) or <strong>America<\\/strong>, is a country primarily located in North America. It is a federal union of 50 states and a federal capital district, Washington, D.C. The 48 contiguous states border Canada to the north and Mexico to the south, with the states of Alaska to the northwest and the archipelagic Hawaii in the Pacific Ocean. The United States also asserts sovereignty over five major island territories and various uninhabited islands. The country has the world\'s third-largest land area, largest exclusive economic zone, and third-largest population, exceeding 334 million. Its three largest metropolitan areas are New York, Los Angeles, and Chicago, and its three most populous states are California, Texas, and Florida.<\\/p>\"}}',0,'0400$daa4878a15c03264c69b558d6a8aada5:fc83d36bec4dc88934c89082f9984c6c'),
(56,1731323337,2,'BE',1,0,8,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"synonyms\":\"United States of America\",\"short_description\":\"\"},\"newRecord\":{\"synonyms\":\"\",\"short_description\":\"America\"}}',0,'0400$1afd5f4ad8c631e3f892dc643532ce7b:fc83d36bec4dc88934c89082f9984c6c'),
(57,1731323367,2,'BE',1,0,8,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"short_description\":\"America\"},\"newRecord\":{\"short_description\":\"\"}}',0,'0400$ca242a6578d8eb177f1dd7cfc4a791ce:fc83d36bec4dc88934c89082f9984c6c'),
(58,1731323419,2,'BE',1,0,8,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"synonyms\":\"\",\"short_description\":\"\"},\"newRecord\":{\"synonyms\":\"United States of America\",\"short_description\":\"America\"}}',0,'0400$aee09fd69a0099493cd6a7363e8b573e:fc83d36bec4dc88934c89082f9984c6c'),
(59,1731323429,2,'BE',1,0,8,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"word\":\"USA\"},\"newRecord\":{\"word\":\"\"}}',0,'0400$3bb42f638f9a1ffaa4ad043920683132:fc83d36bec4dc88934c89082f9984c6c'),
(60,1731323448,2,'BE',1,0,8,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"word\":\"\"},\"newRecord\":{\"word\":\"ASA\"}}',0,'0400$f54ddb7ad7244731b74001b8043fa4b1:fc83d36bec4dc88934c89082f9984c6c'),
(61,1731323457,2,'BE',1,0,8,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"word\":\"ASA\"},\"newRecord\":{\"word\":\"USA\"}}',0,'0400$7fc06b3705d46ac3f9aeb036f3d94eec:fc83d36bec4dc88934c89082f9984c6c'),
(62,1731323461,2,'BE',1,0,8,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"hidden\":0},\"newRecord\":{\"hidden\":\"1\"}}',0,'0400$eeeea2474540b7b6f0ad70d0c0c39cd3:fc83d36bec4dc88934c89082f9984c6c'),
(63,1731323467,2,'BE',1,0,8,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"}}',0,'0400$1b6f399aaefa3a56aaa9d5c6129d70d2:fc83d36bec4dc88934c89082f9984c6c'),
(64,1731323553,1,'BE',1,0,9,'tx_in2glossar_domain_model_definition','{\"uid\":9,\"pid\":2,\"tstamp\":1731323553,\"crdate\":1731323553,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\",\"word\":\"\",\"synonyms\":\"xc\",\"short_description\":\"fd\",\"description\":\"<p>cdsc<\\/p>\",\"tooltip\":0}',0,'0400$1e07bee78530548f7930a4d6b2298950:ff43c111545e30bb92536d6e42492fa1'),
(65,1731323559,4,'BE',1,0,9,'tx_in2glossar_domain_model_definition',NULL,0,'0400$9aa9abbd7286cdf2983d844ca6d8e831:ff43c111545e30bb92536d6e42492fa1'),
(66,1731323633,1,'BE',1,0,10,'tx_in2glossar_domain_model_definition','{\"uid\":10,\"pid\":2,\"tstamp\":1731323633,\"crdate\":1731323633,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\",\"word\":\"A\",\"synonyms\":\"Ab\",\"short_description\":\"Ab\",\"description\":\"<p>AB<\\/p>\",\"tooltip\":0}',0,'0400$c1e0b1a07515843dbeb8cd1d7f09b8a3:4a5748c5537781a6e2f89fa48b0a6fe1'),
(67,1731323639,4,'BE',1,0,10,'tx_in2glossar_domain_model_definition',NULL,0,'0400$9058d9a742da3417ecfd3ea1f1db2ea6:4a5748c5537781a6e2f89fa48b0a6fe1'),
(68,1731505660,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"config\":\"page = PAGE\\r\\npage.10 = TEXT\\r\\npage.10.value = <h1>in2glossar Dev Env<\\/h1>\\r\\npage.100 = CONTENT\\r\\npage.100 {\\r\\n    table = tt_content\\r\\n    select {\\r\\n        orderBy = sorting\\r\\n        where = {#colPos}=0\\r\\n    }\\r\\n}\\r\\nconfig.contentObjectExceptionHandler = 0\"},\"newRecord\":{\"config\":\"page = PAGE\\r\\npage.10 = TEXT\\r\\npage.10.value = <h1>in2glossar Dev Env<\\/h1>\\r\\npage.100 = CONTENT\\r\\npage.100 {\\r\\n    table = tt_content\\r\\n    select {\\r\\n        orderBy = sorting\\r\\n        where = {#colPos}=0\\r\\n    }\\r\\n}\\r\\nconfig.contentObjectExceptionHandler = 00\\r\\npage.includeCSS.tx_in2glossar = EXT:in2glossar\\/Resources\\/Public\\/Css\\/in2glossar.css\"}}',0,'0400$0b6a0e48f26859c5a5e4a0d07c4b0a07:35af6288617af54964e77af08c30949a'),
(69,1731505808,2,'BE',1,0,3,'tt_content','{\"oldRecord\":{\"bodytext\":\"<p>Have you ever been to Australia?<\\/p>\"},\"newRecord\":{\"bodytext\":\"<p>Have you ever been to Australia?<\\/p>\\r\\n<p>Australia<\\/p>\\r\\n<p>australia<\\/p>\"}}',0,'0400$977cf96ceb1385def99728c76ebe3dc8:b92300cfb5d1d3645c9cb212a7f56c1f'),
(70,1731507046,2,'BE',1,0,1,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"tooltip\":0},\"newRecord\":{\"tooltip\":\"1\"}}',0,'0400$fcd71fa0f64eefebf56c75484f26f79d:d2b7b2935ce6ff53dca8bf6e5561666f'),
(71,1731507359,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"\"},\"newRecord\":{\"constants\":\"\\nplugin.tx_in2glossar.settings.targetPage = 3\\nplugin.tx_in2glossar.settings.storagePid = 2\"}}',0,'0400$8446f8ee6fac128d8c8606bb0d4967d8:35af6288617af54964e77af08c30949a'),
(72,1731507868,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"\\nplugin.tx_in2glossar.settings.targetPage = 3\\nplugin.tx_in2glossar.settings.storagePid = 2\"},\"newRecord\":{\"constants\":\"plugin.tx_in2glossar.settings.targetPage = 3\\r\\nplugin.tx_in2glossar.settings.storagePid = 2\"}}',0,'0400$c418f64446a2808ff5786a28a2e36283:35af6288617af54964e77af08c30949a'),
(73,1731508113,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"include_static_file\":\"EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/,EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/Styling\\/,EXT:in2glossar\\/Configuration\\/TypoScript\"},\"newRecord\":{\"include_static_file\":\"EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/,EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/Styling\\/\"}}',0,'0400$b1588333a69015596c81f0b4e61954b9:35af6288617af54964e77af08c30949a'),
(74,1731512510,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"include_static_file\":\"EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/,EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/Styling\\/\"},\"newRecord\":{\"include_static_file\":\"EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/,EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/Styling\\/,EXT:in2glossar\\/Configuration\\/TypoScript\"}}',0,'0400$58e648afcd8361f69e9cc31b9c8c0fe2:35af6288617af54964e77af08c30949a'),
(75,1736949568,2,'BE',1,0,3,'tt_content','{\"oldRecord\":{\"bodytext\":\"<p>Have you ever been to Australia?<\\/p>\\r\\n<p>Australia<\\/p>\\r\\n<p>australia<\\/p>\"},\"newRecord\":{\"bodytext\":\"<p>Have you ever been to Australia?<\\/p>\"}}',0,'0400$d1005ead4f746d244786174983775c5f:b92300cfb5d1d3645c9cb212a7f56c1f'),
(76,1736949730,1,'BE',1,0,11,'tx_in2glossar_domain_model_definition','{\"uid\":11,\"pid\":2,\"tstamp\":1736949730,\"crdate\":1736949730,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\",\"word\":\"Brazil\",\"synonyms\":\"Federative Republic of Brazil\",\"short_description\":\"\",\"description\":\"\",\"tooltip\":0}',0,'0400$cdc1d4f1fb45474e759ca3ffdd57773f:fb4e0b04049157d8d6fda66ab976175e'),
(77,1736950104,2,'BE',1,0,11,'tx_in2glossar_domain_model_definition','{\"oldRecord\":{\"description\":\"\",\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\"},\"newRecord\":{\"description\":\"<p>Brazil, officially the Federative Republic of Brazil, is the largest country in both South America and Latin America. It spans an area of 8,515,767 square kilometers, making it the world\'s fifth-largest country by area. It is bordered by the Atlantic Ocean to the east and shares borders with every South American country except Chile and Ecuador. Brazil is renowned for its diverse ecosystems, including the Amazon rainforest, which is recognized for its biodiversity and significance for global climate.<\\/p>\",\"l10n_diffsource\":\"{\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\"}\"}}',0,'0400$90722a64760f691a315e5cc76340e735:fb4e0b04049157d8d6fda66ab976175e'),
(78,1736950129,1,'BE',1,0,12,'tx_in2glossar_domain_model_definition','{\"uid\":12,\"pid\":2,\"tstamp\":1736950129,\"crdate\":1736950129,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\",\"word\":\"Canada\",\"synonyms\":\"Canada\",\"short_description\":\"\",\"description\":\"<p>Canada is the second-largest country in the world by total area, spanning 9,984,670 square kilometers. It is located in North America and is bordered by the United States to the south and the Arctic Ocean to the north. Canada is known for its vast landscapes, including forests, mountain ranges, and lakes. It is a bilingual country, with English and French as its official languages.<\\/p>\",\"tooltip\":0}',0,'0400$cbe6195f1f9da5fe23d819afd25fbe36:9417c0b5328184763f397e795a47630c'),
(79,1736950155,1,'BE',1,0,13,'tx_in2glossar_domain_model_definition','{\"uid\":13,\"pid\":2,\"tstamp\":1736950155,\"crdate\":1736950155,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\",\"word\":\"Denmark\",\"synonyms\":\"Kingdom of Denmark\",\"short_description\":\"\",\"description\":\"<p>Denmark, officially the Kingdom of Denmark, is a Nordic country in Northern Europe. It is situated southwest of Sweden and south of Norway, and it borders Germany to the south. Denmark consists of a peninsula, Jutland, and an archipelago of 443 named islands. The country is known for its high standard of living and strong social welfare systems.<\\/p>\",\"tooltip\":0}',0,'0400$4f4a4b1992fc6b232e3ba82cee2a5264:3a29fa54f46df8db4e9875b807b12ba0'),
(80,1736950195,1,'BE',1,0,14,'tx_in2glossar_domain_model_definition','{\"uid\":14,\"pid\":2,\"tstamp\":1736950195,\"crdate\":1736950195,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\",\"word\":\"France\",\"synonyms\":\"French Republic\",\"short_description\":\"\",\"description\":\"<p>France, officially the French Republic, is a country located in Western Europe, with territories in several overseas regions and territories. It is bordered by Belgium, Luxembourg, Germany, Switzerland, Italy, and Spain. France is renowned for its cultural heritage, including art, fashion, cuisine, and history. Paris, its capital, is one of the most visited cities in the world.<\\/p>\",\"tooltip\":0}',0,'0400$fbe2fde408fec1b46194d4d5ffa8213f:b359fe5761c2021d415aa193ce1ecbd7'),
(81,1736950237,1,'BE',1,0,15,'tx_in2glossar_domain_model_definition','{\"uid\":15,\"pid\":2,\"tstamp\":1736950237,\"crdate\":1736950237,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\",\"word\":\"Germany\",\"synonyms\":\"Federal Republic of Germany\",\"short_description\":\"\",\"description\":\"<p>Germany, officially the Federal Republic of Germany, is a country in Central Europe. It is bordered by Denmark to the north, Poland and the Czech Republic to the east, Austria and Switzerland to the south, and France, Luxembourg, Belgium, and the Netherlands to the west. Germany is known for its rich history, cultural contributions, and economic strength as the largest economy in Europe.<\\/p>\",\"tooltip\":0}',0,'0400$616fcc913328f73bd467b6cf1041ceb3:b732a2d2323387ac65c4f29f512d1b40'),
(82,1736950266,1,'BE',1,0,16,'tx_in2glossar_domain_model_definition','{\"uid\":16,\"pid\":2,\"tstamp\":1736950266,\"crdate\":1736950266,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\",\"word\":\"Hungary\",\"synonyms\":\"Hungary\",\"short_description\":\"\",\"description\":\"<p>Hungary is a landlocked country in Central Europe, bordered by Austria, Slovakia, Ukraine, Romania, Serbia, Croatia, and Slovenia. It is known for its cultural heritage, historic architecture, and contributions to music and literature. Budapest, its capital, is famous for its thermal baths and the Danube River.<\\/p>\",\"tooltip\":0}',0,'0400$73b4fbfc96a3169135ad65bd3b7d0935:b62d7515f49e3475ed001e39205d5d92'),
(83,1736950283,1,'BE',1,0,17,'tx_in2glossar_domain_model_definition','{\"uid\":17,\"pid\":2,\"tstamp\":1736950283,\"crdate\":1736950283,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\",\"word\":\"Japan\",\"synonyms\":\"Japan\",\"short_description\":\"\",\"description\":\"<p>Japan is an island country in East Asia, located in the northwest Pacific Ocean. It is made up of four main islands\\u2014Honshu, Hokkaido, Kyushu, and Shikoku\\u2014along with numerous smaller islands. Japan is known for its unique blend of traditional and modern culture, including historic temples and advanced technology. Tokyo, its capital, is one of the largest metropolitan areas in the world.<\\/p>\",\"tooltip\":0}',0,'0400$6a0cb669624a59dec61a70985af67047:c779c8f455787defe1266d739657c991'),
(84,1736950315,1,'BE',1,0,18,'tx_in2glossar_domain_model_definition','{\"uid\":18,\"pid\":2,\"tstamp\":1736950315,\"crdate\":1736950315,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\",\"word\":\"Kenya\",\"synonyms\":\"Republic of Kenya\",\"short_description\":\"\",\"description\":\"<p>Kenya, officially the Republic of Kenya, is a country in East Africa. It is bordered by Tanzania, Uganda, South Sudan, Ethiopia, and Somalia, with a coastline along the Indian Ocean. Kenya is famous for its wildlife, national parks, and the Great Rift Valley. Nairobi, its capital, serves as a hub for commerce and culture.<\\/p>\",\"tooltip\":0}',0,'0400$89517f5e3f7827508db48c6b29102de1:3636e572d2eb01de22e302de9cc1b6e8'),
(85,1736950344,1,'BE',1,0,19,'tx_in2glossar_domain_model_definition','{\"uid\":19,\"pid\":2,\"tstamp\":1736950344,\"crdate\":1736950344,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\",\"word\":\"Luxembourg\",\"synonyms\":\"Grand Duchy of Luxembourg\",\"short_description\":\"\",\"description\":\"<p>Luxembourg, officially the Grand Duchy of Luxembourg, is a small landlocked country in Western Europe. It borders Belgium, France, and Germany. Despite its size, Luxembourg has a strong economy and is one of the world\'s wealthiest countries. The country is known for its medieval old town and financial sector.<\\/p>\",\"tooltip\":0}',0,'0400$23b94b21ea330ab80dc72bc4f1a38cac:6f894f261ffb06e9e2b8f9eae440a4de'),
(86,1736950366,1,'BE',1,0,20,'tx_in2glossar_domain_model_definition','{\"uid\":20,\"pid\":2,\"tstamp\":1736950366,\"crdate\":1736950366,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\",\"word\":\"Norway\",\"synonyms\":\"Kingdom of Norway\",\"short_description\":\"\",\"description\":\"<p>Norway, officially the Kingdom of Norway, is a Nordic country located in Northern Europe. It shares borders with Sweden, Finland, and Russia. Known for its stunning fjords, mountains, and coastline, Norway is a country with a high standard of living and strong environmental policies.<\\/p>\",\"tooltip\":0}',0,'0400$c7a523c4636b06638625d135aa358add:8bbb141db98ac4b764f00db01e42024c'),
(87,1736950391,1,'BE',1,0,21,'tx_in2glossar_domain_model_definition','{\"uid\":21,\"pid\":2,\"tstamp\":1736950391,\"crdate\":1736950391,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\",\"word\":\"Oman\",\"synonyms\":\"Sultanate of Oman\",\"short_description\":\"\",\"description\":\"<p>Oman, officially the Sultanate of Oman, is a country on the southeastern coast of the Arabian Peninsula. It is bordered by the United Arab Emirates, Saudi Arabia, and Yemen, with a coastline along the Arabian Sea and the Gulf of Oman. Oman is known for its historic forts, desert landscapes, and traditional culture.<\\/p>\",\"tooltip\":0}',0,'0400$17d0e1fb674e8bb60ef141fc8a8da7a9:b772423599631670816336a22b92a88f'),
(88,1736950424,1,'BE',1,0,22,'tx_in2glossar_domain_model_definition','{\"uid\":22,\"pid\":2,\"tstamp\":1736950424,\"crdate\":1736950424,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\",\"word\":\"Spain\",\"synonyms\":\"Kingdom of Spain\",\"short_description\":\"\",\"description\":\"<p>Spain, officially the Kingdom of Spain, is a country in Southwestern Europe. It shares borders with Portugal, France, Andorra, and Gibraltar, with coastlines along the Atlantic Ocean and the Mediterranean Sea. Known for its historic cities, art, and cuisine, Spain is also famous for cultural traditions such as flamenco and bullfighting.<\\/p>\",\"tooltip\":0}',0,'0400$745156fae214b1a1ff36558afd2d0dfa:274054255791dfcd3f33463a37e956bc'),
(89,1736950465,1,'BE',1,0,23,'tx_in2glossar_domain_model_definition','{\"uid\":23,\"pid\":2,\"tstamp\":1736950465,\"crdate\":1736950465,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\",\"word\":\"Vietnam\",\"synonyms\":\"Socialist Republic of Vietnam\",\"short_description\":\"\",\"description\":\"<p>Vietnam, officially the Socialist Republic of Vietnam, is a country in Southeast Asia. It is bordered by China, Laos, and Cambodia, with a coastline along the South China Sea. Vietnam is known for its history, cuisine, and natural beauty, including Ha Long Bay and the Mekong Delta.<\\/p>\",\"tooltip\":0}',0,'0400$44dc56070a1c4a4fb68843019c5539d1:a886ac1ce1660f910c1a4867a68dea20'),
(90,1736950488,1,'BE',1,0,24,'tx_in2glossar_domain_model_definition','{\"uid\":24,\"pid\":2,\"tstamp\":1736950488,\"crdate\":1736950488,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\",\"word\":\"Yemen\",\"synonyms\":\"Republic of Yemen\",\"short_description\":\"\",\"description\":\"<p>Yemen, officially the Republic of Yemen, is a country on the southern end of the Arabian Peninsula. It is bordered by Saudi Arabia and Oman, with a coastline along the Red Sea and the Arabian Sea. Known for its ancient cities like Sana\'a, Yemen has a rich history and diverse cultural heritage.<\\/p>\",\"tooltip\":0}',0,'0400$6634c30f410ea3f35d8f0945b6af9045:929dc646e71f05898ffa2e46cb815e41'),
(91,1736950509,1,'BE',1,0,25,'tx_in2glossar_domain_model_definition','{\"uid\":25,\"pid\":2,\"tstamp\":1736950509,\"crdate\":1736950509,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"tooltip\\\":\\\"\\\",\\\"word\\\":\\\"\\\",\\\"synonyms\\\":\\\"\\\",\\\"short_description\\\":\\\"\\\",\\\"description\\\":\\\"\\\"}\",\"word\":\"Zambia\",\"synonyms\":\"Republic of Zambia\",\"short_description\":\"\",\"description\":\"<p>Zambia, officially the Republic of Zambia, is a landlocked country in Southern Africa. It is bordered by Tanzania, Malawi, Mozambique, Zimbabwe, Botswana, Namibia, Angola, and the Democratic Republic of Congo. Zambia is known for its wildlife, national parks, and Victoria Falls, one of the Seven Natural Wonders of the World.<\\/p>\",\"tooltip\":0}',0,'0400$70e749ffe61c4f124e3e2fd4a9029286:1f51cd2d6b489da9522f844263c44949');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) NOT NULL,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created` int(10) unsigned NOT NULL,
  `changed` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  `scope` varchar(100) NOT NULL,
  `request_time` bigint(20) unsigned NOT NULL,
  `meta` mediumtext DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `summary` varchar(40) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`),
  KEY `summary_created` (`summary`,`created`),
  KEY `all_conditions` (`type`,`status`,`scope`,`summary`,`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=163 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  `details_nr` smallint(6) NOT NULL DEFAULT 0,
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `NEWid` varchar(30) NOT NULL DEFAULT '',
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `channel` (`channel`),
  KEY `level` (`level`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES
(1,0,1731073795,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.19.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(2,0,1731076979,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1519978105: Container entry \"TYPO3\\CMS\\Backend\\Security\\SudoMode\\Access\\AccessFactory\" is not available. | TYPO3\\CMS\\Core\\DependencyInjection\\NotFoundException thrown in file /var/www/html/.Build/vendor/typo3/cms-core/Classes/DependencyInjection/FailsafeContainer.php in line 100. Requested URL: https://in2glossar4.ddev.site/typo3/ajax/system-information/render?token=--AnonymizedToken--&skipSessionUpdate=1',5,'php',0,'172.19.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(3,0,1731077314,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Main TypoScript Rendering\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"1\"}',1,0,'','',0,'','info',NULL,NULL),
(4,0,1731077369,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Main TypoScript Rendering\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"2\"}',1,0,'','',0,'','info',NULL,NULL),
(5,0,1731077386,1,1,2,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"Data\",\"table\":\"pages\",\"uid\":2,\"pageTitle\":\"Home\",\"pid\":1}',1,0,'NEW_1','',0,'','info',NULL,NULL),
(6,0,1731077390,1,2,2,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Data\",\"table\":\"pages\",\"uid\":2,\"history\":\"4\"}',2,0,'','',0,'','info',NULL,NULL),
(7,0,1731077417,1,1,1,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"[No title]\",\"table\":\"tt_content\",\"uid\":1,\"pageTitle\":\"Home\",\"pid\":1}',1,0,'NEW672e2526c895b714684325','',0,'','info',NULL,NULL),
(8,0,1731077429,1,2,1,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Test cases\",\"table\":\"tt_content\",\"uid\":1,\"history\":\"6\"}',1,0,'','',0,'','info',NULL,NULL),
(9,0,1731077439,1,1,3,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"Glossary\",\"table\":\"pages\",\"uid\":3,\"pageTitle\":\"Home\",\"pid\":1}',1,0,'NEW_1','',0,'','info',NULL,NULL),
(10,0,1731077441,1,2,3,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Glossary\",\"table\":\"pages\",\"uid\":3,\"history\":\"8\"}',3,0,'','',0,'','info',NULL,NULL),
(11,0,1731077451,1,1,2,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"[No title]\",\"table\":\"tt_content\",\"uid\":2,\"pageTitle\":\"Glossary\",\"pid\":3}',3,0,'NEW672e2546b5810424160856','',0,'','info',NULL,NULL),
(12,0,1731077474,1,2,2,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Glossary\",\"table\":\"tt_content\",\"uid\":2,\"history\":\"10\"}',3,0,'','',0,'','info',NULL,NULL),
(13,0,1731077732,1,1,1,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"Australien\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":1,\"pageTitle\":\"Data\",\"pid\":2}',2,0,'NEW672e2571dcb65728924341','',0,'','info',NULL,NULL),
(14,0,1731077778,1,1,2,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"England\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":2,\"pageTitle\":\"Data\",\"pid\":2}',2,0,'NEW672e266bebd24834999535','',0,'','info',NULL,NULL),
(15,0,1731077791,1,2,1,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Australia\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":1,\"history\":\"13\"}',2,0,'','',0,'','info',NULL,NULL),
(16,0,1731077867,1,1,3,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"India\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":3,\"pageTitle\":\"Data\",\"pid\":2}',2,0,'NEW672e26a28adae148973630','',0,'','info',NULL,NULL),
(17,0,1731077917,1,1,4,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"Mexico\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":4,\"pageTitle\":\"Data\",\"pid\":2}',2,0,'NEW672e270a351df524915266','',0,'','info',NULL,NULL),
(18,0,1731077946,1,1,5,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"Poland\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":5,\"pageTitle\":\"Data\",\"pid\":2}',2,0,'NEW672e27202389a080140006','',0,'','info',NULL,NULL),
(19,0,1731077999,1,1,6,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"Romania\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":6,\"pageTitle\":\"Data\",\"pid\":2}',2,0,'NEW672e27589798b384480760','',0,'','info',NULL,NULL),
(20,0,1731078045,1,1,7,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"Turkey\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":7,\"pageTitle\":\"Data\",\"pid\":2}',2,0,'NEW672e278a67280575809728','',0,'','info',NULL,NULL),
(21,0,1731078171,1,2,2,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Glossary\",\"table\":\"tt_content\",\"uid\":2,\"history\":\"19\"}',3,0,'','',0,'','info',NULL,NULL),
(22,0,1731078196,1,2,2,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Glossary\",\"table\":\"tt_content\",\"uid\":2,\"history\":\"20\"}',3,0,'','',0,'','info',NULL,NULL),
(23,0,1731078209,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.19.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(24,0,1731078344,1,2,1,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Australia\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":1,\"history\":\"21\"}',2,0,'','',0,'','info',NULL,NULL),
(25,0,1731078405,1,2,2,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"England\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":2,\"history\":\"22\"}',2,0,'','',0,'','info',NULL,NULL),
(26,0,1731078454,1,2,3,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"India\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":3,\"history\":\"23\"}',2,0,'','',0,'','info',NULL,NULL),
(27,0,1731078592,1,2,4,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Mexico\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":4,\"history\":\"24\"}',2,0,'','',0,'','info',NULL,NULL),
(28,0,1731078597,1,2,5,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Poland\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":5,\"history\":\"25\"}',2,0,'','',0,'','info',NULL,NULL),
(29,0,1731078598,1,2,5,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Poland\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":5,\"history\":\"26\"}',2,0,'','',0,'','info',NULL,NULL),
(30,0,1731078680,1,2,5,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Poland\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":5,\"history\":\"27\"}',2,0,'','',0,'','info',NULL,NULL),
(31,0,1731078933,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Main TypoScript Rendering\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"28\"}',1,0,'','',0,'','info',NULL,NULL),
(32,0,1731078940,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to undefined method In2code\\In2glossar\\Domain\\Model\\Definition::getWord() | Error thrown in file /var/www/html/Classes/ViewHelpers/IndexViewHelper.php in line 45. Requested URL: https://in2glossar4.ddev.site/glossary',5,'php',0,'172.19.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(33,0,1731079219,1,2,1,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Australia\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":1,\"history\":\"29\"}',2,0,'','',0,'','info',NULL,NULL),
(34,0,1731079238,1,2,2,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"England\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":2,\"history\":\"30\"}',2,0,'','',0,'','info',NULL,NULL),
(35,0,1731079253,1,2,3,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"India\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":3,\"history\":\"31\"}',2,0,'','',0,'','info',NULL,NULL),
(36,0,1731079285,1,2,4,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Mexico\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":4,\"history\":\"32\"}',2,0,'','',0,'','info',NULL,NULL),
(37,0,1731079311,1,2,6,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Romania\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":6,\"history\":\"33\"}',2,0,'','',0,'','info',NULL,NULL),
(38,0,1731079336,1,2,7,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Turkey\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":7,\"history\":\"34\"}',2,0,'','',0,'','info',NULL,NULL),
(39,0,1731079340,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to undefined method In2code\\In2glossar\\Domain\\Model\\Definition::getWord() | Error thrown in file /var/www/html/Classes/ViewHelpers/IndexViewHelper.php in line 45. Requested URL: https://in2glossar4.ddev.site/glossary',5,'php',0,'172.19.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(40,0,1731079341,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to undefined method In2code\\In2glossar\\Domain\\Model\\Definition::getWord() | Error thrown in file /var/www/html/Classes/ViewHelpers/IndexViewHelper.php in line 45. Requested URL: https://in2glossar4.ddev.site/glossary',5,'php',0,'172.19.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(41,0,1731079342,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to undefined method In2code\\In2glossar\\Domain\\Model\\Definition::getWord() | Error thrown in file /var/www/html/Classes/ViewHelpers/IndexViewHelper.php in line 45. Requested URL: https://in2glossar4.ddev.site/glossary',5,'php',0,'172.19.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(42,0,1731079342,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to undefined method In2code\\In2glossar\\Domain\\Model\\Definition::getWord() | Error thrown in file /var/www/html/Classes/ViewHelpers/IndexViewHelper.php in line 45. Requested URL: https://in2glossar4.ddev.site/glossary',5,'php',0,'172.19.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(43,0,1731080337,1,1,4,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"Standard Content\",\"table\":\"pages\",\"uid\":4,\"pageTitle\":\"Home\",\"pid\":1}',1,0,'NEW_1','',0,'','info',NULL,NULL),
(44,0,1731080340,1,2,4,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Standard Content\",\"table\":\"pages\",\"uid\":4,\"history\":\"36\"}',4,0,'','',0,'','info',NULL,NULL),
(45,0,1731080395,1,1,3,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"The fiith Continent\",\"table\":\"tt_content\",\"uid\":3,\"pageTitle\":\"Data\",\"pid\":2}',2,0,'NEW672e30968f7c9333634242','',0,'','info',NULL,NULL),
(46,0,1731080431,1,4,1,'tt_content',0,0,'Moved record \"{title}\" ({table}:{uid}) to page \"{pageTitle}\" ({pid})',1,'content',2,'172.19.0.5','{\"title\":\"Test cases\",\"table\":\"tt_content\",\"uid\":1,\"pageTitle\":\"Standard Content\",\"pid\":4}',1,0,'','',0,'','info',NULL,NULL),
(47,0,1731080431,1,4,1,'tt_content',0,0,'Moved record \"{title}\" ({table}:{uid}) from page \"{pageTitle}\" ({pid}))',1,'content',3,'172.19.0.5','{\"title\":\"Test cases\",\"table\":\"tt_content\",\"uid\":1,\"pageTitle\":\"Home\",\"pid\":1}',4,0,'','',0,'','info',NULL,NULL),
(48,0,1731080431,1,2,1,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Test cases\",\"table\":\"tt_content\",\"uid\":1,\"history\":\"39\"}',4,0,'','',0,'','info',NULL,NULL),
(49,0,1731080440,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.19.0.5','{\"username\":\"admin\",\"command\":4}',-1,0,'','',0,'','info',NULL,NULL),
(50,0,1731080457,1,4,1,'tt_content',0,0,'Moved record \"{title}\" ({table}:{uid}) to page \"{pageTitle}\" ({pid})',1,'content',2,'172.19.0.5','{\"title\":\"Test cases\",\"table\":\"tt_content\",\"uid\":1,\"pageTitle\":\"Home\",\"pid\":1}',4,0,'','',0,'','info',NULL,NULL),
(51,0,1731080457,1,4,1,'tt_content',0,0,'Moved record \"{title}\" ({table}:{uid}) from page \"{pageTitle}\" ({pid}))',1,'content',3,'172.19.0.5','{\"title\":\"Test cases\",\"table\":\"tt_content\",\"uid\":1,\"pageTitle\":\"Standard Content\",\"pid\":4}',1,0,'','',0,'','info',NULL,NULL),
(52,0,1731080466,1,4,3,'tt_content',0,0,'Moved record \"{title}\" ({table}:{uid}) to page \"{pageTitle}\" ({pid})',1,'content',2,'172.19.0.5','{\"title\":\"The fiith Continent\",\"table\":\"tt_content\",\"uid\":3,\"pageTitle\":\"Standard Content\",\"pid\":4}',2,0,'','',0,'','info',NULL,NULL),
(53,0,1731080466,1,4,3,'tt_content',0,0,'Moved record \"{title}\" ({table}:{uid}) from page \"{pageTitle}\" ({pid}))',1,'content',3,'172.19.0.5','{\"title\":\"The fiith Continent\",\"table\":\"tt_content\",\"uid\":3,\"pageTitle\":\"Data\",\"pid\":2}',4,0,'','',0,'','info',NULL,NULL),
(54,0,1731080466,1,2,3,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"The fiith Continent\",\"table\":\"tt_content\",\"uid\":3,\"history\":\"42\"}',4,0,'','',0,'','info',NULL,NULL),
(55,0,1731080493,1,2,3,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"The fiith Continent\",\"table\":\"tt_content\",\"uid\":3,\"history\":\"43\"}',4,0,'','',0,'','info',NULL,NULL),
(56,0,1731080590,1,2,1,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Australia\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":1,\"history\":\"44\"}',2,0,'','',0,'','info',NULL,NULL),
(57,0,1731080598,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.19.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(58,0,1731322408,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.19.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(59,0,1731322606,1,2,5,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Poland\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":5,\"history\":\"45\"}',2,0,'','',0,'','info',NULL,NULL),
(60,0,1731322668,1,2,6,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Romania\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":6,\"history\":\"46\"}',2,0,'','',0,'','info',NULL,NULL),
(61,0,1731322745,1,2,7,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Turkey\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":7,\"history\":\"47\"}',2,0,'','',0,'','info',NULL,NULL),
(62,0,1731322802,1,1,8,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"[No title]\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":8,\"pageTitle\":\"Data\",\"pid\":2}',2,0,'NEW6731e3ac16ca6138861223','',0,'','info',NULL,NULL),
(63,0,1731322820,1,2,1,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Australia\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":1,\"history\":\"49\"}',2,0,'','',0,'','info',NULL,NULL),
(64,0,1731322903,1,2,8,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"USA\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":8,\"history\":\"50\"}',2,0,'','',0,'','info',NULL,NULL),
(65,0,1731322919,1,2,8,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"USA\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":8,\"history\":\"51\"}',2,0,'','',0,'','info',NULL,NULL),
(66,0,1731322973,1,2,8,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"USA\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":8,\"history\":\"52\"}',2,0,'','',0,'','info',NULL,NULL),
(67,0,1731323127,1,2,8,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"USA\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":8,\"history\":\"53\"}',2,0,'','',0,'','info',NULL,NULL),
(68,0,1731323281,1,2,8,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"USA\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":8,\"history\":\"54\"}',2,0,'','',0,'','info',NULL,NULL),
(69,0,1731323284,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.19.0.5','{\"username\":\"admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(70,0,1731323302,1,2,8,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"USA\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":8,\"history\":\"55\"}',2,0,'','',0,'','info',NULL,NULL),
(71,0,1731323303,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.19.0.5','{\"username\":\"admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(72,0,1731323312,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.19.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(73,0,1731323321,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.19.0.5','{\"username\":\"admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(74,0,1731323337,1,2,8,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"USA\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":8,\"history\":\"56\"}',2,0,'','',0,'','info',NULL,NULL),
(75,0,1731323340,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.19.0.5','{\"username\":\"admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(76,0,1731323367,1,2,8,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"USA\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":8,\"history\":\"57\"}',2,0,'','',0,'','info',NULL,NULL),
(77,0,1731323369,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.19.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(78,0,1731323419,1,2,8,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"USA\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":8,\"history\":\"58\"}',2,0,'','',0,'','info',NULL,NULL),
(79,0,1731323429,1,2,8,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"[No title]\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":8,\"history\":\"59\"}',2,0,'','',0,'','info',NULL,NULL),
(80,0,1731323448,1,2,8,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"ASA\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":8,\"history\":\"60\"}',2,0,'','',0,'','info',NULL,NULL),
(81,0,1731323457,1,2,8,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"USA\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":8,\"history\":\"61\"}',2,0,'','',0,'','info',NULL,NULL),
(82,0,1731323461,1,2,8,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"USA\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":8,\"history\":\"62\"}',2,0,'','',0,'','info',NULL,NULL),
(83,0,1731323467,1,2,8,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"USA\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":8,\"history\":\"63\"}',2,0,'','',0,'','info',NULL,NULL),
(84,0,1731323540,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.19.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(85,0,1731323553,1,1,9,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"[No title]\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":9,\"pageTitle\":\"Data\",\"pid\":2}',2,0,'NEW6731e69b7e755687749285','',0,'','info',NULL,NULL),
(86,0,1731323559,1,3,9,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was deleted from page \"{pageTitle}\" ({pid})',1,'content',0,'172.19.0.5','{\"title\":\"[No title]\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":9,\"pageTitle\":\"Data\",\"pid\":2}',2,0,'','',0,'','info',NULL,NULL),
(87,0,1731323602,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.19.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(88,0,1731323633,1,1,10,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"A\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":10,\"pageTitle\":\"Data\",\"pid\":2}',2,0,'NEW6731e6d72bcc8705317635','',0,'','info',NULL,NULL),
(89,0,1731323639,1,3,10,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was deleted from page \"{pageTitle}\" ({pid})',1,'content',0,'172.19.0.5','{\"title\":\"A\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":10,\"pageTitle\":\"Data\",\"pid\":2}',2,0,'','',0,'','info',NULL,NULL),
(90,0,1731505612,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user',1,'172.19.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(91,0,1731505622,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.19.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(92,0,1731505660,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Main TypoScript Rendering\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"68\"}',1,0,'','',0,'','info',NULL,NULL),
(93,0,1731505808,1,2,3,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"The fiith Continent\",\"table\":\"tt_content\",\"uid\":3,\"history\":\"69\"}',4,0,'','',0,'','info',NULL,NULL),
(94,0,1731507046,1,2,1,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Australia\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":1,\"history\":\"70\"}',2,0,'','',0,'','info',NULL,NULL),
(95,0,1731507058,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.19.0.5','{\"username\":\"admin\",\"command\":4}',-1,0,'','',0,'','info',NULL,NULL),
(96,0,1731507359,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Main TypoScript Rendering\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"71\"}',1,0,'','',0,'','info',NULL,NULL),
(97,0,1731507366,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.19.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(98,0,1731507868,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Main TypoScript Rendering\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"72\"}',1,0,'','',0,'','info',NULL,NULL),
(99,0,1731508113,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Main TypoScript Rendering\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"73\"}',1,0,'','',0,'','info',NULL,NULL),
(100,0,1731512510,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Main TypoScript Rendering\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"74\"}',1,0,'','',0,'','info',NULL,NULL),
(101,0,1736949506,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.19.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(102,0,1736949568,1,2,3,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"The fiith Continent\",\"table\":\"tt_content\",\"uid\":3,\"history\":\"75\"}',4,0,'','',0,'','info',NULL,NULL),
(103,0,1736949730,1,1,11,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"Brazil\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":11,\"pageTitle\":\"Data\",\"pid\":2}',2,0,'NEW6787bfca1fe83951182231','',0,'','info',NULL,NULL),
(104,0,1736949760,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.19.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(105,0,1736950104,1,2,11,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Brazil\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":11,\"history\":\"77\"}',2,0,'','',0,'','info',NULL,NULL),
(106,0,1736950129,1,1,12,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"Canada\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":12,\"pageTitle\":\"Data\",\"pid\":2}',2,0,'NEW6787c15dc3489791028083','',0,'','info',NULL,NULL),
(107,0,1736950155,1,1,13,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"Denmark\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":13,\"pageTitle\":\"Data\",\"pid\":2}',2,0,'NEW6787c174a1cc6422878892','',0,'','info',NULL,NULL),
(108,0,1736950195,1,1,14,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"France\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":14,\"pageTitle\":\"Data\",\"pid\":2}',2,0,'NEW6787c1a585e8e133228957','',0,'','info',NULL,NULL),
(109,0,1736950237,1,1,15,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"Germany\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":15,\"pageTitle\":\"Data\",\"pid\":2}',2,0,'NEW6787c1b68ee31990163181','',0,'','info',NULL,NULL),
(110,0,1736950266,1,1,16,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"Hungary\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":16,\"pageTitle\":\"Data\",\"pid\":2}',2,0,'NEW6787c1ec291d3910576876','',0,'','info',NULL,NULL),
(111,0,1736950283,1,1,17,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"Japan\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":17,\"pageTitle\":\"Data\",\"pid\":2}',2,0,'NEW6787c2035bb49962627179','',0,'','info',NULL,NULL),
(112,0,1736950315,1,1,18,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"Kenya\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":18,\"pageTitle\":\"Data\",\"pid\":2}',2,0,'NEW6787c2149cd26953429503','',0,'','info',NULL,NULL),
(113,0,1736950344,1,1,19,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"Luxembourg\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":19,\"pageTitle\":\"Data\",\"pid\":2}',2,0,'NEW6787c2308a9d3199308981','',0,'','info',NULL,NULL),
(114,0,1736950366,1,1,20,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"Norway\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":20,\"pageTitle\":\"Data\",\"pid\":2}',2,0,'NEW6787c25059c74546310951','',0,'','info',NULL,NULL),
(115,0,1736950391,1,1,21,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"Oman\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":21,\"pageTitle\":\"Data\",\"pid\":2}',2,0,'NEW6787c261b834c565935596','',0,'','info',NULL,NULL),
(116,0,1736950424,1,1,22,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"Spain\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":22,\"pageTitle\":\"Data\",\"pid\":2}',2,0,'NEW6787c28b43cf4234065031','',0,'','info',NULL,NULL),
(117,0,1736950465,1,1,23,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"Vietnam\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":23,\"pageTitle\":\"Data\",\"pid\":2}',2,0,'NEW6787c2b513fa5435081355','',0,'','info',NULL,NULL),
(118,0,1736950488,1,1,24,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"Yemen\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":24,\"pageTitle\":\"Data\",\"pid\":2}',2,0,'NEW6787c2c4796bc382767956','',0,'','info',NULL,NULL),
(119,0,1736950509,1,1,25,'tx_in2glossar_domain_model_definition',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.5','{\"title\":\"Zambia\",\"table\":\"tx_in2glossar_domain_model_definition\",\"uid\":25,\"pageTitle\":\"Data\",\"pid\":2}',2,0,'NEW6787c2dfc4135575284478','',0,'','info',NULL,NULL),
(120,0,1736950581,1,2,2,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.5','{\"title\":\"Glossary\",\"table\":\"tt_content\",\"uid\":2,\"history\":0}',3,0,'','',0,'','info',NULL,NULL),
(121,0,1737016838,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.19.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL);
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` mediumtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) NOT NULL DEFAULT '',
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recuid` int(11) NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `ref_table` varchar(255) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`(100),`recuid`),
  KEY `lookup_uid` (`ref_table`(100),`ref_uid`),
  KEY `lookup_string` (`ref_string`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES
('41c26f7d7eafb36485bf3845d77e9f27','tt_content',2,'pages','','','',0,0,'pages',2,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES
(1,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendGroupsExplicitAllowDenyMigration','i:1;'),
(2,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendModulePermissionMigration','i:1;'),
(3,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserLanguageMigration','i:1;'),
(4,'installUpdate','TYPO3\\CMS\\Install\\Updates\\CollectionsExtractionUpdate','i:1;'),
(5,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FeLoginModeExtractionUpdate','i:1;'),
(6,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateSiteSettingsConfigUpdate','i:1;'),
(7,'installUpdate','TYPO3\\CMS\\Install\\Updates\\PasswordPolicyForFrontendUsersUpdate','i:1;'),
(8,'installUpdate','TYPO3\\CMS\\Install\\Updates\\ShortcutRecordsMigration','i:1;'),
(9,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SvgFilesSanitization','i:1;'),
(10,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysFileCollectionIdentifierMigration','i:1;'),
(11,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysFileMountIdentifierMigration','i:1;'),
(12,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysLogChannel','i:1;'),
(13,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysLogSerializationUpdate','i:1;'),
(14,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysTemplateNoWorkspaceMigration','i:1;'),
(15,'installUpdateRows','rowUpdatersDone','a:4:{i:0;s:66:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\L18nDiffsourceToJsonMigration\";i:1;s:77:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\WorkspaceMovePlaceholderRemovalMigration\";i:2;s:76:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\WorkspaceNewPlaceholderRemovalMigration\";i:3;s:69:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\SysRedirectRootPageMoveMigration\";}'),
(16,'extensionDataImport','or/typo3/cms-core/ext_tables_static+adt.sql','s:0:\"\";'),
(17,'extensionDataImport','or/typo3/cms-scheduler/ext_tables_static+adt.sql','s:0:\"\";'),
(18,'extensionDataImport','or/typo3/cms-extbase/ext_tables_static+adt.sql','s:0:\"\";'),
(19,'extensionDataImport','or/typo3/cms-fluid/ext_tables_static+adt.sql','s:0:\"\";'),
(20,'extensionDataImport','or/typo3/cms-install/ext_tables_static+adt.sql','s:0:\"\";'),
(21,'extensionDataImport','or/typo3/cms-backend/ext_tables_static+adt.sql','s:0:\"\";'),
(22,'extensionDataImport','or/typo3/cms-frontend/ext_tables_static+adt.sql','s:0:\"\";'),
(23,'extensionDataImport','or/typo3/cms-adminpanel/ext_tables_static+adt.sql','s:0:\"\";'),
(24,'extensionDataImport','or/typo3/cms-dashboard/ext_tables_static+adt.sql','s:0:\"\";'),
(25,'extensionDataImport','or/typo3/cms-fluid-styled-content/ext_tables_static+adt.sql','s:0:\"\";'),
(26,'extensionDataImport','or/typo3/cms-recycler/ext_tables_static+adt.sql','s:0:\"\";'),
(27,'extensionDataImport','or/typo3/cms-setup/ext_tables_static+adt.sql','s:0:\"\";'),
(28,'extensionDataImport','or/typo3/cms-rte-ckeditor/ext_tables_static+adt.sql','s:0:\"\";'),
(29,'extensionDataImport','or/typo3/cms-belog/ext_tables_static+adt.sql','s:0:\"\";'),
(30,'extensionDataImport','or/typo3/cms-beuser/ext_tables_static+adt.sql','s:0:\"\";'),
(31,'extensionDataImport','or/typo3/cms-extensionmanager/ext_tables_static+adt.sql','s:0:\"\";'),
(32,'extensionDataImport','or/typo3/cms-felogin/ext_tables_static+adt.sql','s:0:\"\";'),
(33,'extensionDataImport','or/typo3/cms-filelist/ext_tables_static+adt.sql','s:0:\"\";'),
(34,'extensionDataImport','or/typo3/cms-info/ext_tables_static+adt.sql','s:0:\"\";'),
(35,'extensionDataImport','or/typo3/cms-lowlevel/ext_tables_static+adt.sql','s:0:\"\";'),
(36,'extensionDataImport','or/typo3/cms-t3editor/ext_tables_static+adt.sql','s:0:\"\";'),
(37,'extensionDataImport','or/typo3/cms-tstemplate/ext_tables_static+adt.sql','s:0:\"\";'),
(38,'extensionDataImport','static+adt.sql','s:0:\"\";'),
(39,'extensionDataImport','or/helhum/typo3-console/ext_tables_static+adt.sql','s:0:\"\";'),
(40,'extensionDataImport','or/ssch/typo3-debug-dump-pass/ext_tables_static+adt.sql','s:0:\"\";'),
(41,'core','formProtectionSessionToken:1','s:64:\"32a40f7bb30660f780d49099f7dca278103ebce1cca3c355c3195f373814f570\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `include_static_file` text DEFAULT NULL,
  `constants` text DEFAULT NULL,
  `config` text DEFAULT NULL,
  `basedOn` tinytext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `static_file_mode` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
INSERT INTO `sys_template` VALUES
(1,1,1731512510,1731073553,0,0,0,0,0,'This is an Empty Site Package TypoScript record.\r\n\r\nFor each website you need a TypoScript record on the main page of your website (on the top level). For better maintenance all TypoScript should be extracted into external files via @import \'EXT:site_myproject/Configuration/TypoScript/setup.typoscript\'',0,'Main TypoScript Rendering',1,3,'EXT:fluid_styled_content/Configuration/TypoScript/,EXT:fluid_styled_content/Configuration/TypoScript/Styling/,EXT:in2glossar/Configuration/TypoScript','plugin.tx_in2glossar.settings.targetPage = 3\r\nplugin.tx_in2glossar.settings.storagePid = 2','page = PAGE\r\npage.10 = TEXT\r\npage.10.value = <h1>in2glossar Dev Env</h1>\r\npage.100 = CONTENT\r\npage.100 {\r\n    table = tt_content\r\n    select {\r\n        orderBy = sorting\r\n        where = {#colPos}=0\r\n    }\r\n}\r\nconfig.contentObjectExceptionHandler = 00\r\npage.includeCSS.tx_in2glossar = EXT:in2glossar/Resources/Public/Css/in2glossar.css',NULL,0,0);
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rowDescription` text DEFAULT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT '',
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `bodytext` mediumtext DEFAULT NULL,
  `bullets_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned NOT NULL DEFAULT 0,
  `imageorient` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `records` text DEFAULT NULL,
  `pages` text DEFAULT NULL,
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `header_link` varchar(1024) NOT NULL DEFAULT '',
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `header_layout` varchar(30) NOT NULL DEFAULT '0',
  `list_type` varchar(255) NOT NULL DEFAULT '',
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 0,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` text DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageheight` int(10) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` mediumtext DEFAULT NULL,
  `accessibility_title` varchar(30) NOT NULL DEFAULT '',
  `accessibility_bypass` smallint(5) unsigned NOT NULL DEFAULT 0,
  `accessibility_bypass_text` varchar(30) NOT NULL DEFAULT '',
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_caption` varchar(255) DEFAULT NULL,
  `table_delimiter` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_enclosure` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_header_position` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `selected_categories` longtext DEFAULT NULL,
  `date` int(11) NOT NULL DEFAULT 0,
  `tx_in2glossar_exclude` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES
(1,'',1,1731080457,1731077417,0,0,0,0,'',256,0,0,0,0,NULL,0,'{\"colPos\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,'menu_subpages','Test cases','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'',0,'','',0,'0','',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0),
(2,'',3,1736950581,1731077451,0,0,0,0,'',256,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"list_type\":\"\",\"pages\":\"\",\"recursive\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tx_in2glossar_exclude\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'list','Glossary','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'2',0,'','',0,'0','in2glossar_main',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0),
(3,'',4,1736949568,1731080395,0,0,0,0,'',256,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"image\":\"\",\"imagewidth\":\"\",\"imageheight\":\"\",\"imageborder\":\"\",\"imageorient\":\"\",\"imagecols\":\"\",\"image_zoom\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tx_in2glossar_exclude\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'textpic','The fiith Continent','','<p>Have you ever been to Australia?</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_key` varchar(60) NOT NULL DEFAULT '',
  `repository` int(11) NOT NULL DEFAULT 1,
  `remote` varchar(100) NOT NULL DEFAULT 'ter',
  `version` varchar(15) NOT NULL DEFAULT '',
  `alldownloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `downloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(150) NOT NULL DEFAULT '',
  `description` mediumtext DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `review_state` int(11) NOT NULL DEFAULT 0,
  `category` int(11) NOT NULL DEFAULT 0,
  `serialized_dependencies` mediumtext DEFAULT NULL,
  `author_name` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `ownerusername` varchar(50) NOT NULL DEFAULT '',
  `md5hash` varchar(35) NOT NULL DEFAULT '',
  `update_comment` mediumtext DEFAULT NULL,
  `authorcompany` varchar(255) NOT NULL DEFAULT '',
  `integer_version` int(11) NOT NULL DEFAULT 0,
  `current_version` int(11) NOT NULL DEFAULT 0,
  `lastreviewedversion` int(11) NOT NULL DEFAULT 0,
  `documentation_link` varchar(2048) DEFAULT NULL,
  `distribution_image` varchar(255) DEFAULT NULL,
  `distribution_welcome_image` varchar(255) DEFAULT NULL,
  `last_updated` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`remote`),
  KEY `index_extrepo` (`extension_key`,`remote`),
  KEY `index_versionrepo` (`integer_version`,`remote`,`extension_key`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--

LOCK TABLES `tx_extensionmanager_domain_model_extension` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_in2glossar_domain_model_definition`
--

DROP TABLE IF EXISTS `tx_in2glossar_domain_model_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_in2glossar_domain_model_definition` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `word` varchar(255) NOT NULL DEFAULT '',
  `synonyms` tinytext NOT NULL,
  `short_description` tinytext NOT NULL,
  `description` text NOT NULL,
  `tooltip` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_in2glossar_domain_model_definition`
--

LOCK TABLES `tx_in2glossar_domain_model_definition` WRITE;
/*!40000 ALTER TABLE `tx_in2glossar_domain_model_definition` DISABLE KEYS */;
INSERT INTO `tx_in2glossar_domain_model_definition` VALUES
(1,2,1731507046,1731077732,0,0,0,0,0,0,NULL,'{\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\",\"starttime\":\"\",\"endtime\":\"\"}','Australia','Commonwealth of Australia','Australian continent','<p><strong>Australia</strong>, officially the <strong>Commonwealth of Australia</strong>, is a country comprising the mainland of the Australian continent, the island of Tasmania and numerous smaller islands. Australia has a total area of 7,688,287&nbsp;km<sup>2</sup> (2,968,464&nbsp;sq&nbsp;mi), making it the sixth-largest country in the world and the largest country by area in Oceania. It is the world\'s oldest, flattest, and driest inhabited continent, with some of the least fertile soils. It is a megadiverse country, and its size gives it a wide variety of landscapes and climates including deserts in the interior and tropical rainforests along the coast.</p>',1),
(2,2,1731079238,1731077778,0,0,0,0,0,0,NULL,'{\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\",\"starttime\":\"\",\"endtime\":\"\"}','England','United Kingdom','Great Britain','<p><strong>England</strong> is a country that is part of the United Kingdom. It is located on the island of Great Britain, of which it covers about 62%, and more than 100 smaller adjacent islands. It has land borders with Scotland to the north and Wales to the west, and is otherwise surrounded by the North Sea to the east, the English Channel to the south, the Celtic Sea to the south-west, and the Irish Sea to the west. Continental Europe lies to the south-east, and Ireland to the west. At the 2021 census, the population was 56,490,048. London is both the largest city and the capital.</p>',0),
(3,2,1731079253,1731077867,0,0,0,0,0,0,NULL,'{\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\",\"starttime\":\"\",\"endtime\":\"\"}','India','Republic of India','South Asia','<p><strong>India</strong>, officially the <strong>Republic of India</strong>, is a country in South Asia. It is the seventh-largest country in the world by area and the most populous country. Bounded by the Indian Ocean on the south, the Arabian Sea on the southwest, and the Bay of Bengal on the southeast, it shares land borders with Pakistan to the west; China, Nepal, and Bhutan to the north; and Bangladesh and Myanmar to the east. In the Indian Ocean, India is in the vicinity of Sri Lanka and the Maldives; its Andaman and Nicobar Islands share a maritime border with Thailand, Myanmar, and Indonesia.</p>\r\n\r\n\r\n\r\n',0),
(4,2,1731079285,1731077917,0,0,0,0,0,0,NULL,'{\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\",\"starttime\":\"\",\"endtime\":\"\"}','Mexico','United Mexican States','southern portion of North America','<p><strong>Mexico</strong>, officially the <strong>United Mexican States</strong>, is a country in the southern portion of North America. Covering 1,972,550&nbsp;km<sup>2</sup> (761,610 sq mi), it is the world\'s 13th largest country by area; with a population of almost 130 million, it is the 10th most populous country and has the most Spanish speakers in the world. Mexico is a constitutional republic comprising 31 states and Mexico City, its capital and largest city, which is among the world\'s most populous metropolitan areas. The country shares land borders with the United States to the north, with Guatemala and Belize to the southeast; as well as maritime borders with the Pacific Ocean to the west, the Caribbean Sea to the southeast, and the Gulf of Mexico to the east.</p>',0),
(5,2,1731322606,1731077946,0,0,0,0,0,0,NULL,'{\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\",\"starttime\":\"\",\"endtime\":\"\"}','Poland','Republic of Poland','country of Poland','<p><strong>Poland</strong>, officially the <strong>Republic of Poland</strong>, is a country in Central Europe. It extends from the Baltic Sea in the north to the Sudetes and Carpathian Mountains in the south, bordered by Lithuania and Russia to the northeast, Belarus and Ukraine to the east, Slovakia and the Czech Republic to the south, and Germany to the west. The territory is characterised by a varied landscape, diverse ecosystems, and temperate transitional climate. Poland is composed of sixteen voivodeships and is the fifth most populous member state of the European Union (EU), with over 38 million people, and the fifth largest EU country by land area, covering a combined area of 312,696&nbsp;km<sup>2</sup> (120,733&nbsp;sq&nbsp;mi). The capital and largest city is Warsaw; other major cities include Kraków, Wrocław, Łódź, Poznań, and Gdańsk.</p>',0),
(6,2,1731322668,1731077999,0,0,0,0,0,0,NULL,'{\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\",\"starttime\":\"\",\"endtime\":\"\"}','Romania','Romania','Romania','<p><strong>Romania</strong> is a country located at the crossroads of Central, Eastern, and Southeast Europe. It borders Ukraine to the north and east, Hungary to the west, Serbia to the southwest, Bulgaria to the south, Moldova to the east, and the Black Sea to the southeast. It has a mainly continental climate, and an area of 238,397&nbsp;km<sup>2</sup> (92,046&nbsp;sq&nbsp;mi) with a population of 19 million people (2023). Romania is the twelfth-largest country in Europe and the sixth-most populous member state of the European Union. Europe\'s second-longest river, the Danube, empties into the Danube Delta in the southeast of the country. The Carpathian Mountains cross Romania from the north to the southwest and include Moldoveanu Peak, at an altitude of 2,544&nbsp;m (8,346&nbsp;ft). Romania\'s capital and largest city is Bucharest. Other major urban centers include Cluj-Napoca, Timișoara, Iași, Constanța and Brașov.</p>',0),
(7,2,1731322745,1731078045,0,0,0,0,0,0,NULL,'{\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\",\"starttime\":\"\",\"endtime\":\"\"}','Turkey','Republic of Türkiye','West Asia','<p><strong>Turkey</strong>, officially the <strong>Republic of Türkiye,</strong> is a country mainly located in Anatolia in West Asia, with a smaller part called East Thrace in Southeast Europe. It borders the Black Sea to the north; Georgia, Armenia, Azerbaijan, and Iran to the east; Iraq, Syria, and the Mediterranean Sea to the south; and the Aegean Sea, Greece, and Bulgaria to the west. Turkey is home to over 85 million people; most are ethnic Turks, while ethnic Kurds are the largest ethnic minority. Officially a secular state, Turkey has a Muslim-majority population. Ankara is Turkey\'s capital and second-largest city, while Istanbul is its largest city and economic and financial center. Other major cities include İzmir, Bursa, and Antalya.</p>',0),
(8,2,1731323467,1731322802,0,0,0,0,0,0,NULL,'{\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\",\"starttime\":\"\",\"endtime\":\"\"}','USA','United States of America','America','<p>The <strong>United States of America</strong> (<strong>USA</strong>), commonly known as the <strong>United States</strong> (<strong>U.S.</strong>) or <strong>America</strong>, is a country primarily located in North America. It is a federal union of 50 states and a federal capital district, Washington, D.C. The 48 contiguous states border Canada to the north and Mexico to the south, with the states of Alaska to the northwest and the archipelagic Hawaii in the Pacific Ocean. The United States also asserts sovereignty over five major island territories and various uninhabited islands. The country has the world\'s third-largest land area, largest exclusive economic zone, and third-largest population, exceeding 334 million. Its three largest metropolitan areas are New York, Los Angeles, and Chicago, and its three most populous states are California, Texas, and Florida.</p>',0),
(9,2,1731323559,1731323553,1,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','','xc','fd','<p>cdsc</p>',0),
(10,2,1731323639,1731323633,1,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','A','Ab','Ab','<p>AB</p>',0),
(11,2,1736950104,1736949730,0,0,0,0,0,0,NULL,'{\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\",\"starttime\":\"\",\"endtime\":\"\"}','Brazil','Federative Republic of Brazil','','<p>Brazil, officially the Federative Republic of Brazil, is the largest country in both South America and Latin America. It spans an area of 8,515,767 square kilometers, making it the world\'s fifth-largest country by area. It is bordered by the Atlantic Ocean to the east and shares borders with every South American country except Chile and Ecuador. Brazil is renowned for its diverse ecosystems, including the Amazon rainforest, which is recognized for its biodiversity and significance for global climate.</p>',0),
(12,2,1736950129,1736950129,0,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','Canada','Canada','','<p>Canada is the second-largest country in the world by total area, spanning 9,984,670 square kilometers. It is located in North America and is bordered by the United States to the south and the Arctic Ocean to the north. Canada is known for its vast landscapes, including forests, mountain ranges, and lakes. It is a bilingual country, with English and French as its official languages.</p>',0),
(13,2,1736950155,1736950155,0,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','Denmark','Kingdom of Denmark','','<p>Denmark, officially the Kingdom of Denmark, is a Nordic country in Northern Europe. It is situated southwest of Sweden and south of Norway, and it borders Germany to the south. Denmark consists of a peninsula, Jutland, and an archipelago of 443 named islands. The country is known for its high standard of living and strong social welfare systems.</p>',0),
(14,2,1736950195,1736950195,0,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','France','French Republic','','<p>France, officially the French Republic, is a country located in Western Europe, with territories in several overseas regions and territories. It is bordered by Belgium, Luxembourg, Germany, Switzerland, Italy, and Spain. France is renowned for its cultural heritage, including art, fashion, cuisine, and history. Paris, its capital, is one of the most visited cities in the world.</p>',0),
(15,2,1736950237,1736950237,0,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','Germany','Federal Republic of Germany','','<p>Germany, officially the Federal Republic of Germany, is a country in Central Europe. It is bordered by Denmark to the north, Poland and the Czech Republic to the east, Austria and Switzerland to the south, and France, Luxembourg, Belgium, and the Netherlands to the west. Germany is known for its rich history, cultural contributions, and economic strength as the largest economy in Europe.</p>',0),
(16,2,1736950266,1736950266,0,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','Hungary','Hungary','','<p>Hungary is a landlocked country in Central Europe, bordered by Austria, Slovakia, Ukraine, Romania, Serbia, Croatia, and Slovenia. It is known for its cultural heritage, historic architecture, and contributions to music and literature. Budapest, its capital, is famous for its thermal baths and the Danube River.</p>',0),
(17,2,1736950283,1736950283,0,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','Japan','Japan','','<p>Japan is an island country in East Asia, located in the northwest Pacific Ocean. It is made up of four main islands—Honshu, Hokkaido, Kyushu, and Shikoku—along with numerous smaller islands. Japan is known for its unique blend of traditional and modern culture, including historic temples and advanced technology. Tokyo, its capital, is one of the largest metropolitan areas in the world.</p>',0),
(18,2,1736950315,1736950315,0,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','Kenya','Republic of Kenya','','<p>Kenya, officially the Republic of Kenya, is a country in East Africa. It is bordered by Tanzania, Uganda, South Sudan, Ethiopia, and Somalia, with a coastline along the Indian Ocean. Kenya is famous for its wildlife, national parks, and the Great Rift Valley. Nairobi, its capital, serves as a hub for commerce and culture.</p>',0),
(19,2,1736950344,1736950344,0,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','Luxembourg','Grand Duchy of Luxembourg','','<p>Luxembourg, officially the Grand Duchy of Luxembourg, is a small landlocked country in Western Europe. It borders Belgium, France, and Germany. Despite its size, Luxembourg has a strong economy and is one of the world\'s wealthiest countries. The country is known for its medieval old town and financial sector.</p>',0),
(20,2,1736950366,1736950366,0,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','Norway','Kingdom of Norway','','<p>Norway, officially the Kingdom of Norway, is a Nordic country located in Northern Europe. It shares borders with Sweden, Finland, and Russia. Known for its stunning fjords, mountains, and coastline, Norway is a country with a high standard of living and strong environmental policies.</p>',0),
(21,2,1736950391,1736950391,0,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','Oman','Sultanate of Oman','','<p>Oman, officially the Sultanate of Oman, is a country on the southeastern coast of the Arabian Peninsula. It is bordered by the United Arab Emirates, Saudi Arabia, and Yemen, with a coastline along the Arabian Sea and the Gulf of Oman. Oman is known for its historic forts, desert landscapes, and traditional culture.</p>',0),
(22,2,1736950424,1736950424,0,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','Spain','Kingdom of Spain','','<p>Spain, officially the Kingdom of Spain, is a country in Southwestern Europe. It shares borders with Portugal, France, Andorra, and Gibraltar, with coastlines along the Atlantic Ocean and the Mediterranean Sea. Known for its historic cities, art, and cuisine, Spain is also famous for cultural traditions such as flamenco and bullfighting.</p>',0),
(23,2,1736950465,1736950465,0,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','Vietnam','Socialist Republic of Vietnam','','<p>Vietnam, officially the Socialist Republic of Vietnam, is a country in Southeast Asia. It is bordered by China, Laos, and Cambodia, with a coastline along the South China Sea. Vietnam is known for its history, cuisine, and natural beauty, including Ha Long Bay and the Mekong Delta.</p>',0),
(24,2,1736950488,1736950488,0,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','Yemen','Republic of Yemen','','<p>Yemen, officially the Republic of Yemen, is a country on the southern end of the Arabian Peninsula. It is bordered by Saudi Arabia and Oman, with a coastline along the Red Sea and the Arabian Sea. Known for its ancient cities like Sana\'a, Yemen has a rich history and diverse cultural heritage.</p>',0),
(25,2,1736950509,1736950509,0,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','Zambia','Republic of Zambia','','<p>Zambia, officially the Republic of Zambia, is a landlocked country in Southern Africa. It is bordered by Tanzania, Malawi, Mozambique, Zimbabwe, Botswana, Namibia, Angola, and the Democratic Republic of Congo. Zambia is known for its wildlife, national parks, and Victoria Falls, one of the Seven Natural Wonders of the World.</p>',0);
/*!40000 ALTER TABLE `tx_in2glossar_domain_model_definition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_scheduler_task`
--

DROP TABLE IF EXISTS `tx_scheduler_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_scheduler_task` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `nextexecution` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_time` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_failure` text DEFAULT NULL,
  `lastexecution_context` varchar(3) NOT NULL DEFAULT '',
  `serialized_task_object` mediumblob DEFAULT NULL,
  `serialized_executions` mediumblob DEFAULT NULL,
  `task_group` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `index_nextexecution` (`nextexecution`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task`
--

LOCK TABLES `tx_scheduler_task` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_scheduler_task_group`
--

DROP TABLE IF EXISTS `tx_scheduler_task_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_scheduler_task_group` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `groupName` varchar(80) NOT NULL DEFAULT '',
  `description` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task_group`
--

LOCK TABLES `tx_scheduler_task_group` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task_group` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-16  9:10:25
